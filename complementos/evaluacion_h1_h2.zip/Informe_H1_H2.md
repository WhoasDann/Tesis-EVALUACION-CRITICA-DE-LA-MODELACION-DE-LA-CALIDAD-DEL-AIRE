**Evaluación de H1 y H2 — cierre de los controles dirigidos**

Actualización: 13 de noviembre de 2026. La carpeta conserva la fecha de inicio del análisis.

Los controles aportan respaldo numérico a ambas hipótesis en los episodios examinados. Se mantienen aumentos de concentración y cambios en el orden entre receptores al modificar la segmentación de las fuentes. La admisibilidad física de las perturbaciones sigue sin acreditarse; por ello, el resultado constituye respaldo parcial y condicionado, sin confirmar íntegramente H1 o H2.

**Qué se comprobó**

La evaluación inicial reconstruyó 360 indicadores desde 3.175.680 valores horarios de las 3.314 corridas archivadas. El control adicional ejecutó 42 casos y verificó sus 4.032 valores horarios: 40 casos con fuentes de 25 y 50 m y dos repeticiones con fuentes de 12,5 m. Las dos repeticiones reprodujeron exactamente las 192 concentraciones horarias de los cuatro puntos correspondientes al panel original. Se usaron además 20 casos archivados de 12,5 m como referencia.

Se examinaron cuatro días de verano (12, 16 y 26 de enero y 20 de febrero de 2017) y el 9 de julio, con BASE y su terna correspondiente, MP10 y MP2,5 y los cuatro receptores. Cada indicador corresponde a 24 horas comunes del mismo día civil. Las emisiones horarias por fuente padre se conservaron; la discrepancia relativa máxima de masa tras escribir las tasas fue 4,83 × 10⁻¹³. Los archivos meteorológicos permanecieron idénticos dentro de cada escenario entre las tres representaciones. Se conservaron las cotas AERMAP propias de cada segmentación.

Las fechas se seleccionaron a partir de resultados ya conocidos. El criterio siguiente quedó escrito antes de conocer las nuevas corridas, pero es retrospectivo respecto de la campaña original. Esta condición no permite presentar el ejercicio como la prueba prospectiva prevista inicialmente en H1.

La recepción examinó también los registros de AERMOD. Cada fuente generó un aviso W320 por su tasa estática QS igual a cero; las tasas horarias se suministraron mediante HOUREMIS y sus masas se verificaron. Los avisos W187, W182 y W181 informan el uso de ADJ_U*, meteorología MMIF y BULKRN, respectivamente. No se encontraron otros códigos de aviso ni errores fatales. Los recibos conservan estos antecedentes.

**Criterio operativo para separar el efecto de la discretización**

Para cada media diaria J, escenario y receptor se calculó:

`e = máximo(|J25 − J12,5|, |J50 − J12,5|)`

Para H1 se exigió `Jterna,12,5 − JBASE,12,5 > eBASE + eterna + 0,00001 µg/m³`. También se comprobó el signo del cambio en las tres segmentaciones. El término 0,00001 cubre la resolución de salida al comparar dos medias; la media diaria de 24 valores a cinco decimales conserva un error máximo de redondeo de 0,000005 por indicador.

El margen obtenido describe la estabilidad frente a las representaciones ensayadas, incluyendo sus cotas asociadas. No estima un error numérico calibrado, un límite riguroso frente a la solución exacta ni un intervalo de confianza. Tampoco se transfiere automáticamente a una media estacional u otra fecha.

Para H2 se exigió que el orden de una pareja cambiara entre BASE y la terna en las tres representaciones y que, para cada configuración, la separación entre receptores a 12,5 m superara la suma de sus márgenes más 0,00001 µg/m³. Así se distinguen las inversiones resueltas de los empates numéricos.

**H1: aumentos frente a BASE**

Se evaluaron 40 contrastes (cinco días × dos fracciones × cuatro receptores). Los 14 aumentos observados con fuentes de 12,5 m se mantuvieron en 25 y 50 m y superaron el margen operativo. Los otros 26 contrastes correspondieron a disminuciones. Estos recuentos describen la selección evaluada; carecen de una interpretación como probabilidad de aumento.

Los cuatro episodios estivales seleccionados por receptor dieron los siguientes resultados para MP10. Las concentraciones, diferencias y márgenes están expresados en µg/m³.

| Receptor | Día | Terna | BASE | Terna | Aumento | Cambio relativo | Margen operativo |
|---|---|---|---:|---:|---:|---:|---:|
| Los Bronces | 2017-01-16 | OBS_U | 519,401 | 860,817 | 341,416188 | 65,73% | 62,337919 |
| Piedra Carvajal | 2017-02-20 | OBS_U | 11,969 | 31,975 | 20,005750 | 167,15% | 0,017507 |
| Sulfatos | 2017-01-12 | OBS_V | 0,960 | 1,815 | 0,855167 | 89,09% | 0,004597 |
| La Paloma | 2017-01-26 | OBS_V | 6,997 | 7,083 | 0,086597 | 1,24% | 0,003738 |

Los Bronces presenta un aumento de 341,416188 µg/m³ frente a un margen de 62,337919 µg/m³. Las diferencias entre terna y BASE son 370,523717, 352,465208 y 341,416188 µg/m³ para fuentes de 50, 25 y 12,5 m. La magnitud cambia, pero el sentido y su separación respecto del margen se conservan. La Paloma también supera su margen, aunque su aumento relativo es pequeño (1,24%). La estabilidad numérica y la importancia ambiental representan preguntas distintas.

![H1 MP10](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Figuras/H1_MP10.png)

Las líneas muestran el mismo escenario al cambiar la segmentación. Las escalas verticales difieren entre paneles; la separación visual debe leerse junto con los valores y porcentajes anotados.

![H1 MP2,5](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Figuras/H1_MP25.png)

**H2: cambios de orden entre receptores**

Se evaluaron 60 contrastes de parejas (cinco días × dos fracciones × seis parejas). Ocho mostraron inversiones que superaron los márgenes en las tres representaciones. Corresponden a cuatro parejas-fecha, cada una evaluada para ambas fracciones. Para MP10 se obtuvo:

| Día | Diferencia A − B | BASE a 12,5 m | Terna a 12,5 m | Margen BASE | Margen terna |
|---|---|---:|---:|---:|---:|
| 2017-07-09 | Piedra Carvajal − La Paloma | 10,155444 | -0,140225 | 0,001192 | 0,000011 |
| 2017-07-09 | Sulfatos − La Paloma | 0,538850 | -0,144187 | 0,000910 | 0,000010 |
| 2017-01-16 | Piedra Carvajal − Sulfatos | 24,183670 | -0,000270 | 0,005913 | 0,000016 |
| 2017-01-16 | Piedra Carvajal − La Paloma | 23,898498 | -0,022874 | 0,006331 | 0,000042 |

Un signo positivo indica que A supera a B; un signo negativo indica el orden contrario. Por ejemplo, el 9 de julio Piedra Carvajal supera a La Paloma en BASE y queda por debajo bajo OBS_U. La inversión Piedra Carvajal–Sulfatos del 16 de enero es numéricamente resuelta, pero su separación con la terna es solo 0,000270 µg/m³. Ese resultado no demuestra una diferencia de relevancia ambiental.

![H2 MP10](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Figuras/H2_orden_MP10.png)

Los recuadros amplían la separación pequeña bajo OBS_U. Esta evaluación respalda la alternativa de H2 referida al orden entre los cuatro puntos. No evalúa el desplazamiento del máximo de toda la malla. Las inversiones estacionales bajo v+ documentadas previamente conservan su alcance original: estos ensayos diarios no constituyen un control de su convergencia estacional.

**Qué implica la condición de perturbación admisible**

Las ternas contienen tres discrepancias medias diarias simultáneas (ΔT, Δu, Δv) calculadas en Piedra Carvajal. Su procedencia y reproducción se verificaron. Aplicarlas a otro día, a la columna MMIF y a un perfil vertical introduce supuestos adicionales. Por ejemplo, OBS_U de verano proviene del 27 de diciembre (23 pares): ΔT = +0,669481 °C, Δu = +3,030182 m/s y Δv = +1,518935 m/s. El 16 de enero, las discrepancias del propio día en la estación fueron +0,710647 °C, −0,542406 m/s y +0,264075 m/s. La terna trasladada no equivale a la discrepancia observada del día de aplicación. La diferencia no demuestra por sí sola imposibilidad física de un escenario contrafactual; sí impide describirlo como una corrección validada para ese día.

El diagnóstico ya disponible aporta tres observaciones relevantes:

- El 16 de enero, el viento WRF de Los Bronces se aproxima al de la columna (RMS vectorial diario de 0,31 m/s), mientras la diferencia estación–columna alcanza 3,57 m/s. La discrepancia de estación incorpora condiciones locales cuya transferencia exige justificación.
- En la hora de mayor aumento de MP10, la rapidez procesada con la terna es 0,46 m/s en Los Bronces, 0,40 m/s en Piedra Carvajal y 0,69 m/s en Sulfatos, cada uno en su episodio. Las tres horas de mayores incrementos explican 58,04%, aproximadamente 100% y 99,52% de la suma de diferencias positivas, respectivamente. La interpretación depende de la circulación durante esas horas, además de la media diaria.
- La Paloma presenta una diferencia vectorial RMS receptor–columna de 5,37 m/s el 26 de enero. El 9 de julio esa diferencia es 5,35 m/s; en Sulfatos alcanza 8,17 m/s. Estas diferencias son diagnósticos espaciales dentro de WRF, no errores observados ni umbrales automáticos de rechazo.

La guía de implementación de AERMOD establece que la representatividad meteorológica requiere examinar las características superficiales y las condiciones de aplicación, y que la proximidad por sí sola no la determina. El diagnóstico del proyecto resulta coherente con esa necesidad, pero no reemplaza la validación local. [EPA, AERMOD Implementation Guide, julio de 2026, sección 3.1](https://gaftp.epa.gov/Air/aqmg/SCRAM/models/preferred/aermod/aermod_implementation_guide.pdf).

La perturbación de ONSITE conserva la humedad, presión, flujos y altura de mezcla de entrada de BASE, mientras AERMET procesa las variables dependientes. No se reintegra WRF. Por tanto, la coexistencia empírica de las tres discrepancias en la estación no acredita el equilibrio dinámico de la columna perturbada.

**Estado de las hipótesis y continuación**

| Componente | Estado y alcance |
|---|---|
| H1: aumento superior al margen operativo | Respaldado en 14 contrastes diarios de los controles seleccionados. |
| H2: cambio de orden resuelto | Respaldado en 8 contrastes de parejas, entre cuatro receptores y en dos episodios. |
| Control numérico de medias estacionales y máximo de malla completa | No evaluado por este lote. |
| Admisibilidad física de las ternas | No acreditada con los antecedentes disponibles. |
| Confirmación integral de H1 y H2 | Respaldo parcial y condicionado; no corresponde declararlas confirmadas íntegramente. |

La continuación requiere documentar la referencia horaria y el tratamiento del horario de verano, el intervalo de medición/integración y las alturas de los sensores de Piedra Carvajal en 2016–2017. El extracto local «MOP DGA División de Hidrología.pdf» contiene marcas de medición a :49, pero no resuelve esos metadatos. La carta «31653.pdf» remite a información adjunta y tampoco los especifica en su texto. Las marcas son compatibles con el emparejamiento bajo la hipótesis civil adoptada; su significado instrumental permanece pendiente.

Con esa información se debe verificar si cambian los pares observación–WRF y las amplitudes de las ternas. La evidencia independiente sobre la circulación y perfiles próximos a los caminos permitiría evaluar la transferencia en las horas dominantes. Si esa evidencia no está disponible, la tesis puede concluir con el alcance de sensibilidad prescrita y respaldo condicionado aquí documentado. Ejecutar las fechas restantes de las mismas ternas ampliaría la cobertura temporal, pero no resolvería esa condición física.

Los controles no modifican las condiciones del contraste normativo: el aporte vial calculado excluye el fondo y las otras fuentes. Estos resultados no establecen un peor caso legal ni una conclusión de cumplimiento.

**Trazabilidad y reproducción**

- [Protocolo de controles](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Criterio_controles_dirigidos.md).
- [Matriz H1](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Controles_dirigidos/H1_robustez.csv) y [matriz H2](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Controles_dirigidos/H2_robustez.csv).
- [Medias de las tres representaciones](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Controles_dirigidos/Medias_tres_discretizaciones.csv).
- [Diagnóstico físico de las 20 combinaciones meteorología–receptor](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Diagnostico_fisico_20_combinaciones.csv).
- [Verificación numérica y huellas](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Controles_dirigidos/Verificacion.json).
- [Evaluación inicial preservada](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Evaluacion_H1_H2_2026-11-12/Resumen.md).

Desde la raíz del proyecto, `python work/evaluacion_h1_h2_20261112/recibir_controles.py` verifica entradas, salidas, recibos y referencias, reconstruye los indicadores y genera las figuras. `python work/evaluacion_h1_h2_20261112/cerrar_evaluacion.py` reconstruye este informe y el diagnóstico físico. Ambos comandos realizan posproceso; las ejecuciones AERMOD se conservan separadas en `Controles_dirigidos/Intentos`.
