"""Audita controles dirigidos y evalúa el criterio retrospectivo congelado."""
import csv
import hashlib
import itertools
import json
import re
import sys
from collections import Counter
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

import controles as c

ROOT = c.ROOT
OUT = ROOT/'outputs/Evaluacion_H1_H2_2026-11-12'
C = c.OUT
EPS = Fraction(1, 100000)
RECEPTORS = ['Los Bronces', 'Piedra Carvajal', 'Sulfatos', 'La Paloma']


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open('w', encoding='utf8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sign(v):
    return 1 if v > EPS else -1 if v < -EPS else 0


def main():
    plan = json.loads((C/'Plan.json').read_text(encoding='utf8'))
    assert json.loads((C/'Estado.json').read_text())['status'] == 'COMPLETE'
    assert not (C/'RUNNING.lock').exists()
    catalog = c.REP.read_catalog()
    coords = json.loads((c.REPO/'datos/horarios/coordenadas.json').read_text())
    receptors = read_csv(c.REPO/'datos/receptores.csv')
    names = {(float(r['x']), float(r['y'])): r['receptor'] for r in receptors}
    indices = {r['receptor']: coords.index([float(r['x']), float(r['y'])]) for r in receptors}
    values, audit, hashes, native_ids = {}, [], {}, set()
    warning_totals = Counter()
    for job in plan['jobs']:
        receipt_file = C/'Recibos'/(job['id']+'.json')
        receipt = json.loads(receipt_file.read_text(encoding='utf8'))
        assert receipt['status'] == 'VERIFIED' and receipt['job'] == job
        assert receipt['binary_sha256'] == c.sha(Path(plan['binary']))
        assert receipt['inputs'] == job['inputs']
        for filename, digest in job['inputs'].items():
            assert c.sha(C/job['folder']/filename) == digest
        for filename, digest in receipt['outputs'].items():
            assert c.sha(C/filename) == digest
        error_path = next(C/n for n in receipt['outputs'] if n.endswith('errores.out'))
        warnings = Counter()
        for line in error_path.read_text().splitlines():
            match = re.match(r'\s*\S+\s+([WEF]\d{3})\s+', line)
            if match:
                assert match[1] in {'W320','W187','W182','W181'}, (job['id'], line)
                warnings[match[1]] += 1
                if match[1] == 'W320':
                    assert line.rstrip().endswith('QS')
        parameters = [s.split() for s in (C/job['folder']/'fuentes_aermod.inc').read_text().splitlines() if 'SRCPARAM' in s]
        assert warnings['W320'] == len(parameters) and all(float(s[3]) == 0 for s in parameters)
        assert all(warnings[k] == 1 for k in ['W187','W182','W181'])
        warning_totals.update(warnings)
        hours_path = next(C/n for n in receipt['outputs'] if n.endswith('receptor_horas.out'))
        records = {}
        for line in hours_path.read_text().splitlines():
            if not line.strip() or line.lstrip().startswith('*'):
                continue
            f = line.split()
            xy = float(f[0]), float(f[1])
            assert xy in names and f[8] in job['expected_hours']
            key = f[8], names[xy]
            assert key not in records
            records[key] = Fraction(Decimal(f[2]))
            assert records[key] >= 0
        assert len(records) == 96
        for receptor in RECEPTORS:
            avg = sum(records[h, receptor] for h in job['expected_hours'])/24
            key = job['season'], job['day'], job['scenario'], job['pollutant'], receptor, job['resolution_m']
            assert key not in values
            values[key] = avg
            stored = next(r['mean'] for r in receipt['means'] if names[r['x'], r['y']] == receptor)
            assert abs(float(avg)-stored) < 1e-10
        native_ids.add(job['native_id'])
        hashes[str(receipt_file.relative_to(OUT))] = c.sha(receipt_file)
        audit.append(dict(job=job['id'], hourly_values=96, status='VERIFIED', seconds=receipt['seconds'],
                          W320_QS=warnings['W320'], W187_ADJ_USTAR=warnings['W187'], W182_MMIF=warnings['W182'],
                          W181_BULKRN=warnings['W181'], fatal_errors=0))

    canary_max = 0
    for cid in sorted(native_ids):
        case = catalog['casos'][cid]
        hours, data = c.REP.reference_hours(cid, case)
        assert len(hours) == 24 and all(case['hour_states'][h] == 'VALIDA' for h in hours)
        assert {c.REP.civil_mapping()[case['season'], h] for h in hours} == {case['day']}
        for receptor in RECEPTORS:
            avg = Fraction(sum(data[i*40+indices[receptor]] for i in range(24)), 2400000)
            key = case['season'], case['day'], case['scenario'], case['pollutant'], receptor, 12.5
            if key in values:
                assert avg == values[key]
            values[key] = avg
        # Both four-point reruns must agree with every archived hourly output.
        if cid in ['VERANO_20170116_BASE_MP10', 'VERANO_20170116_OBS_U_MP10']:
            r = json.loads((C/'Recibos'/(cid+'_F12p5.json')).read_text())
            hp = next(C/n for n in r['outputs'] if n.endswith('receptor_horas.out'))
            parsed = {}
            for line in hp.read_text().splitlines():
                if not line.strip() or line.lstrip().startswith('*'):
                    continue
                f = line.split()
                parsed[f[8], names[float(f[0]), float(f[1])]] = Fraction(Decimal(f[2]))
            for i, h in enumerate(hours):
                for receptor in RECEPTORS:
                    difference = abs(parsed[h, receptor]-Fraction(data[i*40+indices[receptor]], 100000))
                    canary_max = max(canary_max, difference)
            assert canary_max == 0

    references = read_csv(OUT/'Indicadores_reconstruidos.csv')
    expected = {(r['temporada'], r['fecha'], r['escenario'], r['fraccion'], r['receptor']): float(r['media_ug_m3'])
                for r in references if r['indicador'] == 'MEDIA_DIARIA_EPISODIO'}
    maximum_cotejo = max(abs(float(v)-expected[k[:-1]]) for k, v in values.items() if k[-1] == 12.5)
    assert maximum_cotejo < 1e-10
    configurations = sorted({k[:4] for k in values if k[2] != 'BASE'})
    h1, h2, daily = [], [], []
    for key, v in sorted(values.items()):
        daily.append(dict(temporada=key[0], fecha=key[1], escenario=key[2], fraccion=key[3], receptor=key[4],
                          fuente_m=key[5], media_ug_m3=float(v)))
    for season, day, scenario, pm in configurations:
        def get(sc, receptor, res):
            return values[season, day, sc, pm, receptor, res]
        def margin(sc, receptor):
            return max(abs(get(sc, receptor, res)-get(sc, receptor, 12.5)) for res in [25, 50])
        for receptor in RECEPTORS:
            base, pert = get('BASE', receptor, 12.5), get(scenario, receptor, 12.5)
            delta = pert-base
            tolerance = margin('BASE', receptor)+margin(scenario, receptor)+EPS
            differences = {res: get(scenario, receptor, res)-get('BASE', receptor, res) for res in [12.5, 25, 50]}
            h1.append(dict(temporada=season, fecha=day, escenario=scenario, fraccion=pm, receptor=receptor,
                           BASE_12p5=float(base), escenario_12p5=float(pert), delta_12p5=float(delta),
                           delta_pct=float(100*delta/base) if base else '',
                           delta_25=float(differences[25]), delta_50=float(differences[50]),
                           e_BASE=float(margin('BASE', receptor)), e_escenario=float(margin(scenario, receptor)),
                           delta_operacional=float(tolerance), aumento_tres_representaciones=all(d > EPS for d in differences.values()),
                           aumento_supera_margen=delta > tolerance,
                           admision_fisica='PENDIENTE', alcance='MEDIA_DIARIA; CRITERIO_RETROSPECTIVO'))
        for a, b in itertools.combinations(RECEPTORS, 2):
            gaps = {(sc, res): get(sc, a, res)-get(sc, b, res) for sc in ['BASE', scenario] for res in [12.5, 25, 50]}
            mb = margin('BASE', a)+margin('BASE', b)+EPS
            mp = margin(scenario, a)+margin(scenario, b)+EPS
            inverse = {res: sign(gaps['BASE', res])*sign(gaps[scenario, res]) == -1 for res in [12.5, 25, 50]}
            robust = all(inverse.values()) and abs(gaps['BASE', 12.5]) > mb and abs(gaps[scenario, 12.5]) > mp
            h2.append(dict(temporada=season, fecha=day, escenario=scenario, fraccion=pm, receptor_A=a, receptor_B=b,
                           separacion_BASE_12p5=float(gaps['BASE', 12.5]), separacion_escenario_12p5=float(gaps[scenario, 12.5]),
                           separacion_BASE_25=float(gaps['BASE', 25]), separacion_escenario_25=float(gaps[scenario, 25]),
                           separacion_BASE_50=float(gaps['BASE', 50]), separacion_escenario_50=float(gaps[scenario, 50]),
                           margen_BASE=float(mb), margen_escenario=float(mp), inversion_12p5=inverse[12.5],
                           inversion_tres_representaciones=all(inverse.values()), inversion_supera_margenes=robust,
                           admision_fisica='PENDIENTE', alcance='ORDEN_ENTRE_CUATRO_RECEPTORES; MEDIA_DIARIA; RETROSPECTIVO'))
    assert len(h1) == 40 and len(h2) == 60 and len(daily) == 240
    for name, rows in [('H1_robustez.csv', h1), ('H2_robustez.csv', h2), ('Medias_tres_discretizaciones.csv', daily), ('Recepcion.csv', audit)]:
        write_csv(C/name, rows)

    def totals(rows):
        return dict(H1_comparaciones=len(rows), H1_aumentos_12p5=sum(r['delta_12p5']>float(EPS) for r in rows),
                    H1_aumentos_estables=sum(r['aumento_tres_representaciones'] for r in rows),
                    H1_aumentos_superan_margen=sum(r['aumento_supera_margen'] for r in rows))
    verification = dict(status='VERIFIED_NUMERICAL_CONTROLS_PHYSICAL_ADMISSION_PENDING', new_runs=len(audit),
                        native_hourly_values=sum(r['hourly_values'] for r in audit), archived_reference_cases=len(native_ids),
                        source_resolutions_m=[12.5, 25, 50], canaries=2, canary_max_hourly_difference=float(canary_max),
                        max_mean_difference_against_initial=float(maximum_cotejo), max_relative_mass_error=plan['max_relative_mass_error'],
                        H1=totals(h1), H1_por_receptor={r: totals([x for x in h1 if x['receptor']==r]) for r in RECEPTORS},
                        H2=dict(comparaciones=len(h2), inversiones_12p5=sum(r['inversion_12p5'] for r in h2),
                                inversiones_estables=sum(r['inversion_tres_representaciones'] for r in h2),
                                inversiones_superan_margenes=sum(r['inversion_supera_margenes'] for r in h2)),
                        receipt_hashes=hashes, elapsed_sum_seconds=sum(r['seconds'] for r in audit),
                        warning_counts=dict(warning_totals),
                        warning_interpretation='W320 flags one zero static QS placeholder per source; hourly rates are supplied by HOUREMIS. W187/W182/W181 report ADJ_USTAR, MMIF, BULKRN. No other warning or fatal code found.',
                        scope='Five selected full civil days. Empirical robustness, not calibrated numerical error or seasonal convergence.')
    c.save(C/'Verificacion.json', verification)
    figures(daily, h1, h2)
    print(json.dumps({k:v for k,v in verification.items() if k != 'receipt_hashes'}, ensure_ascii=False, indent=2))


def figures(daily, h1, h2):
    sys.path.insert(0, 'C:/Users/dcitu/Documents/Codex/2026-10-19/es/work/python_deps')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':10, 'axes.spines.top':False, 'axes.spines.right':False,
                         'axes.grid':True, 'grid.alpha':.2, 'savefig.facecolor':'white'})
    folder = OUT/'Figuras'
    folder.mkdir(exist_ok=True)
    anchors = [('Los Bronces', '2017-01-16', 'OBS_U'), ('Piedra Carvajal', '2017-02-20', 'OBS_U'),
               ('Sulfatos', '2017-01-12', 'OBS_V'), ('La Paloma', '2017-01-26', 'OBS_V')]
    for pm, label in [('MP10','MP10'), ('MP25','MP2,5')]:
        fig, axs = plt.subplots(2, 2, figsize=(11, 7.5), layout='constrained')
        for ax, (receptor, day, sc) in zip(axs.flat, anchors):
            for scenario, color in [('BASE','#334e68'), (sc,'#c65c18')]:
                subset = {r['fuente_m']:r['media_ug_m3'] for r in daily if r['fecha']==day and r['receptor']==receptor
                          and r['fraccion']==pm and r['escenario']==scenario}
                ax.plot([0,1,2], [subset[x] for x in [50,25,12.5]], 'o-', color=color, label=scenario)
            row = next(r for r in h1 if r['fecha']==day and r['receptor']==receptor and r['fraccion']==pm)
            state = 'Supera el margen' if row['aumento_supera_margen'] else 'No supera el margen'
            ax.set_title(receptor+' · '+day, loc='left', fontweight='bold')
            ax.set_xticks([0,1,2], ['50 m','25 m','12,5 m'])
            ax.set_xlabel('Segmentación de las fuentes')
            ax.set_ylabel('Media diaria (µg/m³)')
            ax.text(.02,.98, f"Δ12,5 = {row['delta_12p5']:.4g} µg/m³ ({row['delta_pct']:+.2f}%)\nMargen = {row['delta_operacional']:.4g} µg/m³ · {state}",
                    transform=ax.transAxes, va='top', fontsize=9, bbox=dict(facecolor='white', alpha=.9, edgecolor='none'))
            ax.margins(y=.42)
            ax.legend(loc='lower right', frameon=True, fontsize=9)
        fig.suptitle(f'H1 · {label}: respuesta diaria y estabilidad frente a la segmentación\nSelección retrospectiva; admisibilidad física pendiente', fontsize=13)
        fig.savefig(folder/f'H1_{pm}.png', dpi=180)
        fig.savefig(folder/f'H1_{pm}.svg')
        plt.close(fig)
    selections = [('2017-01-16','Piedra Carvajal','Sulfatos'), ('2017-01-16','Piedra Carvajal','La Paloma'),
                  ('2017-07-09','Piedra Carvajal','La Paloma'), ('2017-07-09','Sulfatos','La Paloma')]
    fig, axs = plt.subplots(2,2, figsize=(11,7.5), layout='constrained')
    for ax, (day,a,b) in zip(axs.flat,selections):
        row=next(r for r in h2 if r['fecha']==day and r['fraccion']=='MP10' and r['receptor_A']==a and r['receptor_B']==b)
        for sc, color in [('BASE','#334e68'),('escenario','#c65c18')]:
            ax.plot([0,1,2],[row[f'separacion_{sc}_{r}'] for r in ['50','25','12p5']], 'o-', color=color,
                    label='BASE' if sc=='BASE' else row['escenario'])
        ax.axhline(0,color='#555',linewidth=1,linestyle='--')
        ax.set_xticks([0,1,2],['50 m','25 m','12,5 m'])
        ax.set_title(f'{a} − {b}\n{day}',loc='left',fontweight='bold')
        ax.set_ylabel('Diferencia de medias MP10 (µg/m³)')
        ax.set_xlabel('Segmentación de las fuentes')
        state='Inversión supera los márgenes' if row['inversion_supera_margenes'] else 'Inversión no supera los márgenes'
        ax.text(.02,.98,state,transform=ax.transAxes,va='top',fontsize=9)
        ax.margins(y=.3)
        ax.legend(loc='best',fontsize=9)
        small = [row[f'separacion_escenario_{r}'] for r in ['50','25','12p5']]
        ax.text(.02,.05, f"BASE12,5: {row['separacion_BASE_12p5']:+.6g}\nOBS_U12,5: {row['separacion_escenario_12p5']:+.6g} µg/m³",
                transform=ax.transAxes, va='bottom', fontsize=9)
        if abs(row['separacion_BASE_12p5']) > 50*max(abs(x) for x in small):
            inset = ax.inset_axes([.47,.18,.47,.33])
            inset.plot([0,1,2],small,'o-',color='#c65c18',markersize=4)
            inset.axhline(0,color='#555',linestyle='--',linewidth=.8)
            m = max(abs(x) for x in small)
            inset.set_ylim(-1.5*m,.3*m)
            inset.set_xticks([0,1,2],['50','25','12,5'])
            inset.set_title('Detalle de OBS_U (µg/m³)',fontsize=8)
            inset.tick_params(labelsize=8)
            inset.ticklabel_format(axis='y',style='sci',scilimits=(-3,3))
            inset.yaxis.get_offset_text().set_fontsize(8)
    fig.suptitle('H2 · Signos opuestos entre BASE y la terna indican una inversión del orden\nControl de episodios; admisibilidad física pendiente',fontsize=13)
    fig.savefig(folder/'H2_orden_MP10.png',dpi=180)
    fig.savefig(folder/'H2_orden_MP10.svg')
    plt.close(fig)


if __name__ == '__main__':
    main()
