"""Controles dirigidos con fuentes de 50/25 m y los cuatro receptores exactos."""
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT/'publicacion/repositorio'
OUT = ROOT/'outputs/Evaluacion_H1_H2_2026-11-12/Controles_dirigidos'
OLD = Path('C:/Users/dcitu/Documents/Codex/2026-10-08/hem/outputs')
BINARY = OLD/'Control_cotas_fuentes12p5_2026-10-19/Binarios/aermod.exe'
SPEC = importlib.util.spec_from_file_location('reproducir', REPO/'reproducir.py')
REP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REP)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    temp.replace(path)


def geometry(raw):
    locations, parameters = {}, {}
    for line in raw.decode().splitlines():
        fields = line.split()
        if fields[1] == 'LOCATION':
            assert fields[3] == 'LINE'
            locations[fields[2]] = tuple(map(float, fields[4:]))
        elif fields[1] == 'SRCPARAM':
            parameters[fields[2]] = tuple(map(float, fields[3:]))
    assert locations.keys() == parameters.keys()
    area = {s: math.hypot(v[2]-v[0], v[3]-v[1])*parameters[s][2]
            for s, v in locations.items()}
    return locations, parameters, area


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT/'Plan.json').exists():
        raise FileExistsError('El plan ya existe. La reanudación usa run.')
    catalog = REP.read_catalog()
    assert sha(BINARY) == '599b491b021c7ec254ba3a1062386f287e56e54a0d3bb9b67cfa72275d6916da'
    anchors = [
        ('VERANO', '20170116', 'OBS_U'),
        ('VERANO', '20170220', 'OBS_U'),
        ('VERANO', '20170112', 'OBS_V'),
        ('VERANO', '20170126', 'OBS_V'),
        ('INVIERNO', '20170709', 'OBS_U'),
    ]
    with gzip.open(REPO/'datos/geometria/Comunes_fuentes.csv.gz', 'rt') as stream:
        fine_rows = list(csv.DictReader(stream))
    fine_ids = [r['id_fuente_aermod'] for r in fine_rows]
    base_case = catalog['casos']['VERANO_20170116_BASE_MP10']
    fine_raw = REP.read_object(catalog, base_case['inputs']['fuentes_aermod.inc'])
    fine_loc, fine_par, fine_area = geometry(fine_raw)
    assert list(fine_loc) == fine_ids
    four = list(csv.DictReader((REPO/'datos/receptores.csv').open(encoding='utf8')))
    coords = {(float(r['x']), float(r['y'])) for r in four}
    receptor_raw = REP.read_object(catalog, base_case['inputs']['receptores.inc'])
    receptor_lines = [line for line in receptor_raw.decode().splitlines()
                      if tuple(map(float, line.split()[2:4])) in coords]
    assert len(receptor_lines) == 4
    receptors = ('\n'.join(receptor_lines)+'\n').encode()
    areas = np.array([fine_area[s] for s in fine_ids])
    variants = {12.5: dict(raw=fine_raw, ids=fine_ids, area=areas)}
    for resolution, ancestor in [(25, 'id_fuente_padre'), (50, 'id_fuente_50m')]:
        raw = (OLD/f'Convergencia_conjunta_2026-10-16/F{resolution}/Fuentes/fuentes_aermod.inc').read_bytes()
        loc, params, area = geometry(raw)
        ids = list(loc)
        positions = {s: i for i, s in enumerate(ids)}
        parent = np.array([positions[row[ancestor]] for row in fine_rows])
        assert set(parent) == set(range(len(ids)))
        for row in fine_rows:
            assert fine_par[row['id_fuente_aermod']] == params[row[ancestor]]
        variants[resolution] = dict(raw=raw, ids=ids, area=np.array([area[s] for s in ids]), parent=parent)

    blocks, cached_rates, emission_paths = [], {}, {}
    mass_errors = []
    source_checks = []
    for season, day, scenario in anchors:
        for sc in ['BASE', scenario]:
            for pm in ['MP10', 'MP25']:
                native = f'{season}_{day}_{sc}_{pm}'
                case = catalog['casos'][native]
                assert all(v == 'VALIDA' for v in case['hour_states'].values())
                assert len(case['hour_states']) == 24
                assert REP.civil_mapping()[season, max(case['hour_states'])] == case['day']
                assert REP.civil_mapping()[season, min(case['hour_states'])] == case['day']
                assert case['inputs']['fuentes_aermod.inc'] == base_case['inputs']['fuentes_aermod.inc']
                controls = [25, 50]
                if day == '20170116' and pm == 'MP10':
                    controls = [12.5]+controls
                for res in controls:
                    label = str(res).replace('.', 'p')
                    job_id = f'{native}_F{label}'
                    folder = OUT/'Entradas'/job_id
                    folder.mkdir(parents=True, exist_ok=False)
                    variant = variants[res]
                    (folder/'fuentes_aermod.inc').write_bytes(variant['raw'])
                    (folder/'receptores.inc').write_bytes(receptors)
                    for name in ['met.SFC', 'met.PFL']:
                        (folder/name).write_bytes(REP.read_object(catalog, case['inputs'][name]))
                    original_control = REP.read_object(catalog, case['inputs']['aermod.inp']).decode()
                    control = re.sub(r'Q000001-Q012263', variant['ids'][0]+'-'+variant['ids'][-1], original_control)
                    (folder/'aermod.inp').write_text(control, encoding='ascii', newline='\n')
                    emission_hash = case['inputs'][pm+'.emi']
                    emission_key = emission_hash, res
                    emission_file = folder/(pm+'.emi')
                    if emission_key in emission_paths:
                        shutil.copy2(emission_paths[emission_key], emission_file)
                    else:
                        with emission_file.open('wb') as stream:
                            for hour, digest in catalog['emisiones'][emission_hash]:
                                cache_key = digest, res
                                if cache_key not in cached_rates:
                                    raw = REP.read_object(catalog, digest)
                                    fields = [line.split() for line in raw.decode().splitlines()]
                                    assert [f[0] for f in fields] == fine_ids
                                    rates = np.array([float(f[1]) for f in fields])
                                    if res == 12.5:
                                        result = raw
                                    else:
                                        masses = np.bincount(variant['parent'], weights=rates*areas,
                                                             minlength=len(variant['ids']))
                                        coarse = masses/variant['area']
                                        lines = [f'{s:<12s} {q:.12E}\n' for s, q in zip(variant['ids'], coarse)]
                                        result = ''.join(lines).encode()
                                        serialized = np.array([float(s.split()[1]) for s in lines])
                                        residual = abs(serialized*variant['area']-masses)
                                        relative = np.divide(residual, abs(masses), out=np.zeros_like(masses), where=masses!=0)
                                        assert relative.max() < 6e-13
                                        mass_errors.append(float(relative.max()))
                                    cached_rates[cache_key] = result
                                body = cached_rates[cache_key]
                                y, m, d = map(int, case['day'].split('-'))
                                prefix = f'SO HOUREMIS {y%100:02d} {m:2d} {d:2d} {hour:2d} '.encode()
                                stream.write(prefix+body[:-1].replace(b'\n', b'\n'+prefix)+b'\n')
                        emission_paths[emission_key] = emission_file
                    if res == 12.5:
                        assert sha(emission_file) == emission_hash
                    inputs = {p.name: sha(p) for p in folder.iterdir()}
                    blocks.append(dict(id=job_id, native_id=native, resolution_m=res,
                                       season=season, day=case['day'], scenario=sc, pollutant=pm,
                                       folder=str(folder.relative_to(OUT)), inputs=inputs,
                                       receptor_count=4, expected_hours=sorted(case['hour_states'])))
                    source_checks.append(dict(job=job_id, source_hash=inputs['fuentes_aermod.inc']))
    assert len(blocks) == 42
    blocks.sort(key=lambda b: (b['resolution_m'] != 12.5, b['day'] != '2017-01-16', b['id']))
    plan = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                purpose='Retrospective episode controls for H1 and receptor-order branch of H2',
                selection='Four previously documented summer receptor episodes and winter 9 July order reversal',
                physical_admission='REQUIRES_SEPARATE_EVIDENCE',
                interpretation='Stability across tested source discretizations with their own archived elevations',
                threshold='Empirical spread relative to 12.5 m is reported per indicator; no calibrated error bound',
                binary=str(BINARY), binary_sha256=sha(BINARY), workers=2,
                max_relative_mass_error=max(mass_errors), jobs=blocks)
    save(OUT/'Plan.json', plan)
    print(json.dumps(dict(jobs=len(blocks), max_relative_mass_error=max(mass_errors))), flush=True)


def execute(job, plan):
    receipt = OUT/'Recibos'/(job['id']+'.json')
    if receipt.exists():
        record = json.loads(receipt.read_text(encoding='utf8'))
        assert record['inputs'] == job['inputs'] and record['status'] == 'VERIFIED'
        for path, digest in record['outputs'].items():
            assert sha(OUT/path) == digest
        return record
    if (OUT/'STOP_AFTER_CURRENT').exists():
        return None
    origin = OUT/job['folder']
    for name, digest in job['inputs'].items():
        assert sha(origin/name) == digest
    attempts = OUT/'Intentos'/job['id']
    attempts.mkdir(parents=True, exist_ok=True)
    folder = attempts/f'intento_{len(list(attempts.iterdir()))+1:02d}'
    folder.mkdir()
    for name in job['inputs']:
        shutil.copy2(origin/name, folder/name)
    started = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    with (folder/'console.log').open('wb') as log:
        process = subprocess.Popen([plan['binary'], 'aermod.inp', 'aermod.out'], cwd=folder,
                                   stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'execution.json', dict(pid=process.pid, started_utc=started, status='RUNNING'))
        code = process.wait()
    seconds = time.monotonic()-timer
    save(folder/'execution.json', dict(pid=process.pid, started_utc=started, seconds=seconds, returncode=code))
    assert code == 0 and 'AERMOD Finishes Successfully' in (folder/'aermod.out').read_text(errors='replace'), folder
    records = {}
    for line in (folder/'receptor_horas.out').read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('*'):
            continue
        f = line.split()
        assert f[6:8] == ['1-HR', 'ALL']
        key = f[8], float(f[0]), float(f[1])
        assert key not in records and key[0] in job['expected_hours']
        value = float(f[2])
        assert math.isfinite(value) and value >= 0
        records[key] = value
    assert len(records) == 96
    points = {(x, y) for _, x, y in records}
    assert len(points) == 4
    assert all((h, *point) in records for h in job['expected_hours'] for point in points)
    if job['resolution_m'] == 12.5:
        catalog = REP.read_catalog()
        hours, values = REP.reference_hours(job['native_id'], catalog['casos'][job['native_id']])
        coords = json.loads((REPO/'datos/horarios/coordenadas.json').read_text())
        maximum = max(abs(round(records[h, *point]*100000)-values[i*40+coords.index(list(point))])
                      for i, h in enumerate(hours) for point in points)
        assert maximum == 0, (job['id'], maximum)
    means = [dict(x=x, y=y, mean=sum(records[h, x, y] for h in job['expected_hours'])/24)
             for x, y in sorted(points)]
    names = ['aermod.out', 'receptor_horas.out', 'receptor_24h.out', 'resumen.sum', 'errores.out', 'execution.json']
    record = dict(status='VERIFIED', job=job, inputs=job['inputs'], seconds=seconds,
                  binary_sha256=plan['binary_sha256'], means=means,
                  outputs={str((folder/n).relative_to(OUT)): sha(folder/n) for n in names})
    save(receipt, record)
    print(json.dumps(dict(id=job['id'], seconds=round(seconds, 2), status='VERIFIED')), flush=True)
    return record


def run():
    plan = json.loads((OUT/'Plan.json').read_text(encoding='utf8'))
    assert sha(Path(plan['binary'])) == plan['binary_sha256']
    lock = OUT/'RUNNING.lock'
    with lock.open('x') as stream:
        stream.write(str(os.getpid()))
    (OUT/'Recibos').mkdir(exist_ok=True)
    try:
        # Verify four-receptor equivalence before executing altered discretizations.
        for job in plan['jobs']:
            if job['resolution_m'] == 12.5:
                execute(job, plan)
        jobs = [j for j in plan['jobs'] if j['resolution_m'] != 12.5]
        with ThreadPoolExecutor(max_workers=plan['workers']) as pool:
            tasks = [pool.submit(execute, job, plan) for job in jobs]
            for task in as_completed(tasks):
                task.result()
                save(OUT/'Estado.json', dict(status='RUNNING', pid=os.getpid(),
                     receipts=len(list((OUT/'Recibos').glob('*.json'))), total=len(plan['jobs']),
                     updated_utc=datetime.now(timezone.utc).isoformat()))
        count = len(list((OUT/'Recibos').glob('*.json')))
        save(OUT/'Estado.json', dict(status='COMPLETE' if count == len(plan['jobs']) else 'SOFT_STOPPED',
             receipts=count, total=len(plan['jobs']), updated_utc=datetime.now(timezone.utc).isoformat()))
    except Exception as exc:
        save(OUT/'Estado.json', dict(status='FAILED', error=str(exc),
             receipts=len(list((OUT/'Recibos').glob('*.json'))), updated_utc=datetime.now(timezone.utc).isoformat()))
        raise
    finally:
        lock.unlink()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['prepare', 'run'])
    args = parser.parse_args()
    prepare() if args.operation == 'prepare' else run()
