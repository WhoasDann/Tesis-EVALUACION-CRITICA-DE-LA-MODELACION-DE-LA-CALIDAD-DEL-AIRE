# Controles dirigidos de discretización

La selección conserva los cuatro episodios estivales de las fichas existentes y añade el 9 de julio, que muestra inversiones invernales en el orden de receptores. Las fechas estivales y sus ternas son 16 de enero OBS_U, 20 de febrero OBS_U, 12 de enero OBS_V y 26 de enero OBS_V. En invierno se emplea OBS_U. Para cada fecha se compara la terna con BASE, ambas fracciones y los cuatro puntos exactos. La selección es retrospectiva.

La referencia publicada utiliza 12,5 m. Se calculan las representaciones archivadas de 25 y 50 m, con sus propias cotas de AERMAP. Cada fuente gruesa recibe la masa horaria de sus descendientes finos, dividida por su propia área. Se comprueba la conservación de masa tras escribir las tasas. La meteorología y las propiedades de las fuentes se conservan dentro de cada escenario.

Antes de ejecutar las variantes se repiten dos casos de 12,5 m con cuatro receptores para verificar igualdad horaria con el panel original. Se preparan 40 casos de discretización y dos de equivalencia del panel. Los intentos y sus salidas se conservan con huellas digitales.

Para cada receptor e indicador se define un margen empírico e igual al mayor valor absoluto entre J25−J12,5 y J50−J12,5. H1 se examina mediante ΔJ12,5 > eBASE + eescenario + 0,00001 µg/m³. También se informan las diferencias BASE–escenario en las tres representaciones. Este criterio verifica separación frente al conjunto de representaciones probado. Su alcance es la robustez empírica de los controles ejecutados.

En H2 se evalúan las seis parejas de receptores. Una inversión queda respaldada por este control cuando el signo cambia entre BASE y la terna en las tres representaciones y, en cada escenario, la separación de la referencia excede la suma de los márgenes de los dos receptores más 0,00001 µg/m³. Se conservan además los estados de orden de cada representación.

Estos márgenes incorporan los cambios de segmentación y sus cotas asociadas. La cota física y la transferencia meteorológica requieren sus propias evaluaciones. Los indicadores estacionales conservan el alcance de su evaluación inicial. Este lote controla medias de días completos en cinco episodios y permite evaluar la alternativa de H2 referida al orden entre los cuatro receptores.
