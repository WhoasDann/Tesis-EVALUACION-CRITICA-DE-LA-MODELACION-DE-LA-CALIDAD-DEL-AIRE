# Evaluación retrospectiva de H1 y H2

La evaluación se registra el 12 de noviembre de 2026, después de conocer los resultados estacionales y de episodios. Se conservan las hipótesis del manuscrito y su condición de admisibilidad meteorológica. El análisis utiliza las salidas archivadas de las 3.314 corridas de la versión pública 8bb43e9dd0b82ca049e72a08aa6c3e7acd2574b1.

## Comparaciones

Se reconstruyen las concentraciones diarias desde los enteros horarios del archivo publicado, conservando máscaras y correspondencia entre hora LST y día civil. Se cotejan las medias reconstruidas con las tablas de referencia. Los cuatro receptores son Los Bronces, Piedra Carvajal, Sulfatos y La Paloma, para MP10 y MP2,5.

Se evalúan dos indicadores existentes. El primero es la media sobre las 87 fechas de verano y las 90 fechas de invierno completas y comunes a las nueve configuraciones estacionales. El segundo es la media diaria de los episodios documentados para las ternas empíricas, comparada con BASE en la misma fecha. Los días y escenarios de episodios proceden de la tabla archivada.

H1 se examina mediante la diferencia escenario menos BASE. H2 se examina mediante las seis parejas de los cuatro receptores. Una inversión exige signos opuestos de la diferencia entre receptores en BASE y en el escenario, con magnitud superior al margen de resolución en ambas situaciones. El cambio de orden entre receptores satisface la alternativa de H2 referida al orden. El alcance espacial de esta evaluación corresponde a los cuatro puntos.

## Resolución y robustez numérica

Las concentraciones horarias originales se escribieron con cinco decimales. El análisis emplea 0,00001 µg/m³ como margen de resolución de una diferencia entre dos indicadores. Para medias de valores redondeados a cinco decimales, la suma de los dos errores máximos de redondeo es de un incremento de salida. Se conserva este margen al promediar días, sin asumir independencia de los redondeos. Las comparaciones se realizan con aritmética racional para evitar empates afectados por el redondeo binario.

Este margen caracteriza la resolución de los valores publicados. La tolerancia completa de H1 incorpora además la estabilidad de la representación de fuentes y el cálculo del indicador. Su valor queda pendiente cuando los controles disponibles no cubren ambos escenarios, período e indicador de la comparación. Las diferencias de refinamiento históricas se presentan con sus fechas y geometrías. La extrapolación de esas diferencias a otros regímenes requiere justificación propia.

## Admisibilidad y conclusión

La matriz conserva campos separados para resolución de salida, controles de discretización y admisibilidad física. Las fichas de transferencia existentes se incorporan como evidencia documental. Una diferencia positiva o una inversión resuelta a la precisión de salida constituye evidencia numérica de sensibilidad. El respaldo completo de las hipótesis depende también de la admisibilidad del escenario.

La regla se aplica a todas las comparaciones del alcance indicado, incluyendo disminuciones, órdenes conservados y diferencias sin resolver. Los casos ya citados en el manuscrito se identifican como ejemplos conocidos antes de este análisis. Las necesidades de control se documentan antes de decidir nuevas corridas.
