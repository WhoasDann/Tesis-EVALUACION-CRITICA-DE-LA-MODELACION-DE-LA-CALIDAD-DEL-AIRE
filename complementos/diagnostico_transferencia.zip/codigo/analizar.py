"""Physical compatibility diagnostics; no model dispatch or fitted correction."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/Transferencia_fisica_2026-11-13'
PRE=ROOT/'outputs/Cierre_cientifico_2026-11-05/Transferencia_WRF'
MET=ROOT/'outputs/Sensibilidad_estacional_2026-10-29/Meteorologia'
TERNAS=ROOT/'outputs/Seleccion_adversa_2026-11-04/Contraste_ternas_observadas'
RECEPTORS=['Los Bronces','Piedra Carvajal','Sulfatos','La Paloma']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf8')
def csv(name,data):pd.DataFrame(data).to_csv(OUT/name,index=False)

def day_hours(day):
    a=pd.Timestamp(day).tz_localize('America/Santiago',nonexistent='shift_forward')
    b=(pd.Timestamp(day)+pd.Timedelta(days=1)).tz_localize('America/Santiago',nonexistent='shift_forward')
    return int((b.tz_convert('UTC')-a.tz_convert('UTC')).total_seconds()/3600)


def sfc(folder):
    names=['year','month','day','jday','hour','H','ustar','wstar','vptg','zic','zim','L','z0','bowen','albedo','WS','WD','zref','T_K','ztemp','ipcode','rain','RH','pressure','ccvr','WADJ','SUBflag']
    df=pd.read_csv(folder/'met.SFC',sep=r'\s+',skiprows=1,header=None,names=names)
    df['end']=pd.to_datetime(dict(year=df.year,month=df.month,day=df.day))+pd.to_timedelta(df.hour,unit='h')
    df['valid']=(df.WS<99)&(df.T_K<999)&(df.ustar>=0)&(df.zim>0)
    return df


def profiles():
    design=json.loads((TERNAS/'Diseno.json').read_text(encoding='utf8'))
    rows=[];audits=[];levels=[]
    for proto in design['prototypes']:
        season,sc=proto['season'],proto['scenario']
        base,pert=MET/season/'BASE',TERNAS/'Meteorologia'/season/sc
        b=(base/'ONSITE.DAT').read_text().splitlines()
        p=(pert/'ONSITE.DAT').read_text().splitlines()
        assert len(b)==len(p) and len(b)%30==0
        bs,ps=sfc(base),sfc(pert)
        ms=ps.merge(bs,on='end',suffixes=('','_BASE'),validate='one_to_one').set_index('end')
        dt,du,dv=proto['delta']
        audit=dict(season=season,scenario=sc,source_day=proto['source_day'],hours=0,above_PBL_changes=0,
                   max_T_operator_error=0.,max_vector_operator_error=0.,max_DT01_error=0.,
                   unchanged_header_hours=0,unchanged_upperair=sha(base/'upper.dat')==sha(pert/'upper.dat'),
                   inputs={str(f):sha(f) for f in [base/'ONSITE.DAT',pert/'ONSITE.DAT',base/'met.SFC',pert/'met.SFC',base/'met.PFL',pert/'met.PFL']})
        for k in range(0,len(b),30):
            stamp=b[k][:10]
            end=pd.to_datetime(stamp[:8])+pd.Timedelta(hours=int(stamp[8:]))
            season_start=pd.Timestamp('2016-12-21' if season=='VERANO' else '2017-06-21')
            season_end=pd.Timestamp('2017-03-21' if season=='VERANO' else '2017-09-21')
            if not season_start<end<=season_end or end not in ms.index or not ms.loc[end,'valid']:continue
            offset=3 if season=='VERANO' else 4
            utc=end+pd.Timedelta(hours=offset)
            civil=(utc-pd.Timedelta(hours=1)).tz_localize('UTC').tz_convert('America/Santiago')
            if civil.strftime('%Y-%m-%d') >= ('2017-03-21' if season=='VERANO' else '2017-09-21'):continue
            assert ms.loc[end,'valid_BASE']
            audit['hours']+=1
            assert b[k]==p[k]
            audit['unchanged_header_hours']+=1
            h=float(b[k][40:50]);assert h>10
            level_b=[];level_p=[]
            for j in range(1,30):
                z=float(b[k+j][10:20]);assert z==float(p[k+j][10:20])
                weight=lambda ref:1-3*np.clip((z-ref)/(h-ref),0,1)**2+2*np.clip((z-ref)/(h-ref),0,1)**3
                tb=float(b[k+j][40:50]) if j!=2 else np.nan
                tp=float(p[k+j][40:50]) if j!=2 else np.nan
                ub=vb=up=vp=np.nan
                if j>=2:
                    wb,db=float(b[k+j][20:30]),float(b[k+j][30:40])
                    wp,dp=float(p[k+j][20:30]),float(p[k+j][30:40])
                    ub,vb=-wb*np.sin(np.deg2rad(db)),-wb*np.cos(np.deg2rad(db))
                    up,vp=-wp*np.sin(np.deg2rad(dp)),-wp*np.cos(np.deg2rad(dp))
                    err=float(np.hypot(up-ub-weight(10)*du,vp-vb-weight(10)*dv))
                    audit['max_vector_operator_error']=max(audit['max_vector_operator_error'],err)
                if j!=2:
                    audit['max_T_operator_error']=max(audit['max_T_operator_error'],abs(tp-tb-weight(2)*dt))
                if z>=h:
                    audit['above_PBL_changes']+=int(b[k+j]!=p[k+j])
                level_b.append((z,tb,ub,vb));level_p.append((z,tp,up,vp))
            eb=abs(float(p[k+1][60:70])-(float(p[k+3][40:50])-float(p[k+1][40:50])))
            audit['max_DT01_error']=max(audit['max_DT01_error'],eb)
            lb=np.array(level_b);lp=np.array(level_p)
            # Dry hydrostatic gradient proxy. Not a measured potential-temperature gradient.
            good=np.isfinite(lb[:,1])&(lb[:,0]<=500)
            z=lb[good,0];gb=np.diff(lb[good,1])/np.diff(z)+9.80665/1004.;gp=np.diff(lp[good,1])/np.diff(z)+9.80665/1004.
            gradient_precision=.001/np.diff(z)
            flipped=(gb>gradient_precision)&(gp<-gradient_precision)
            flipped_back=(gb<-gradient_precision)&(gp>gradient_precision)
            wb=lb[np.isfinite(lb[:,2])];wp=lp[np.isfinite(lp[:,2])]
            lower=(wb[:,0]<=500)
            shear_b=np.hypot(np.diff(wb[lower,2]),np.diff(wb[lower,3]))/np.diff(wb[lower,0])
            shear_p=np.hypot(np.diff(wp[lower,2]),np.diff(wp[lower,3]))/np.diff(wp[lower,0])
            m=ms.loc[end]
            rows.append(dict(season=season,scenario=sc,source_day=proto['source_day'],end_LST=end,time_UTC=utc,
                day=civil.strftime('%Y-%m-%d'),mixing_height_ONSITE=h,BASE_WS=m.WS_BASE,WS=m.WS,
                turn_deg=abs((m.WD-m.WD_BASE+180)%360-180),BASE_H=m.H_BASE,H=m.H,BASE_ustar=m.ustar_BASE,ustar=m.ustar,
                BASE_L=m.L_BASE,L=m.L,BASE_zim=m.zim_BASE,zim=m.zim,
                max_shear_BASE_s_1=float(shear_b.max()),max_shear_pert_s_1=float(shear_p.max()),
                min_dry_gradient_BASE_K_m=float(gb.min()),min_dry_gradient_pert_K_m=float(gp.min()),
                max_dry_gradient_change_K_m=float(abs(gp-gb).max()),
                layers_positive_to_negative=int(flipped.sum()),layers_negative_to_positive=int(flipped_back.sum()),
                any_positive_to_negative=bool(flipped.any()),any_negative_to_positive=bool(flipped_back.any()),
                H_nonpositive_new_negative_layer=bool(m.H<=0 and flipped.any()),
                maximum_prescribed_shear_scale_s_1=1.5*np.hypot(du,dv)/(h-10)))
            if civil.strftime('%Y-%m-%d') in design['civil_days'][season]:
                for bval,pval in zip(lb,lp):
                    levels.append(dict(season=season,scenario=sc,time_UTC=utc,day=civil.strftime('%Y-%m-%d'),
                        z_m=bval[0],T_BASE=bval[1],T_pert=pval[1],u_BASE=bval[2],u_pert=pval[2],v_BASE=bval[3],v_pert=pval[3],mixing_height=h))
        assert audit['above_PBL_changes']==0 and audit['max_T_operator_error']<=.00051
        assert audit['max_vector_operator_error']<.0011 and audit['max_DT01_error']<.00001
        audits.append(audit)
    result=pd.DataFrame(rows)
    summary=[]
    for (s,sc),d in result.groupby(['season','scenario']):
        summary.append(dict(season=s,scenario=sc,hours=len(d),new_negative_gradient_hours=int(d.any_positive_to_negative.sum()),
            removed_negative_gradient_hours=int(d.any_negative_to_positive.sum()),
            new_negative_gradient_with_nonpositive_H=int(d.H_nonpositive_new_negative_layer.sum()),
            min_MHGT=float(d.mixing_height_ONSITE.min()),max_shear_BASE=float(d.max_shear_BASE_s_1.max()),
            max_shear_pert=float(d.max_shear_pert_s_1.max()),p95_shear_pert=float(d.max_shear_pert_s_1.quantile(.95)),
            max_abs_H_change=float(abs(d.H-d.BASE_H).max()),max_abs_ustar_change=float(abs(d.ustar-d.BASE_ustar).max()),
            max_abs_zim_change=float(abs(d.zim-d.BASE_zim).max()),min_WS=float(d.WS.min()),turn_gt90_hours=int((d.turn_deg>90).sum())))
    csv('Diagnostico_operador_horario.csv',result);csv('Diagnostico_operador_resumen.csv',summary)
    csv('Perfiles_ONSITE_episodios.csv',levels);save('Verificacion_operador.json',audits)
    print(json.dumps(summary,ensure_ascii=False),flush=True)


def metrics(a,b):
    q=a.merge(b,on='time_UTC',suffixes=('','_ref'),validate='one_to_one')
    dv=np.hypot(q.u10-q.u10_ref,q.v10-q.v10_ref)
    good=(q.WS10>=1)&(q.WS10_ref>=1)
    direction=abs((q.WD10-q.WD10_ref+180)%360-180)
    anomalies={k:q[k]-q.groupby('day')[k].transform('mean') for k in ['u10','u10_ref','v10','v10_ref','T2_C','T2_C_ref']}
    result=dict(hours=len(q),wind_vector_RMS=float(np.sqrt(np.mean(dv**2))),wind_vector_median=float(np.median(dv)),
                wind_vector_p90=float(np.quantile(dv,.9)),T_RMS=float(np.sqrt(np.mean((q.T2_C-q.T2_C_ref)**2))),
                corr_u=float(q.u10.corr(q.u10_ref)),corr_v=float(q.v10.corr(q.v10_ref)),corr_T=float(q.T2_C.corr(q.T2_C_ref)),
                corr_u_daily_anomaly=float(anomalies['u10'].corr(anomalies['u10_ref'])),
                corr_v_daily_anomaly=float(anomalies['v10'].corr(anomalies['v10_ref'])),
                corr_T_daily_anomaly=float(anomalies['T2_C'].corr(anomalies['T2_C_ref'])),
                mean_temperature_difference=float((q.T2_C-q.T2_C_ref).mean()),
                direction_hours=int(good.sum()),mean_direction_difference=float(direction[good].mean()),
                opposed_direction_fraction=float((direction[good]>90).mean()),
                same_HFX_sign_fraction=float((np.sign(q.HFX_W_m2)==np.sign(q.HFX_W_m2_ref)).mean()),
                mean_PBLH_difference=float((q.PBLH_m-q.PBLH_m_ref).mean()))
    return result,q


def surface():
    receipt=json.loads((OUT/'Recepcion_extraccion.json').read_text())
    assert receipt['csv_sha256']==sha(OUT/'Superficie_estacional_seis_puntos.csv')
    x=pd.read_csv(OUT/'Superficie_estacional_seis_puntos.csv',parse_dates=['time_UTC'])
    x['start_civil']=(x.time_UTC-pd.Timedelta(hours=1)).dt.tz_localize('UTC').dt.tz_convert('America/Santiago')
    x['day']=x.start_civil.dt.strftime('%Y-%m-%d')
    # Extracted left boundary is for interpolation only, not a study interval.
    starts={'VERANO':'2016-12-21','INVIERNO':'2017-06-21'}
    x=x[x.apply(lambda r:r.day>=starts[r.season],axis=1)].copy()
    spatial=[];daily=[];all_pairs=[]
    for season,g in x.groupby('season'):
        for ref in ['Estacion_PC','Columna_MMIF']:
            b=g[g.point.eq(ref)]
            for point in ['Estacion_PC','Columna_MMIF']+RECEPTORS:
                if point==ref:continue
                a=g[g.point.eq(point)]
                m,p=metrics(a,b)
                spatial.append(dict(season=season,reference=ref,point=point,regime='TODAS',**m))
                p['comparison_reference']=ref
                p['vector_difference']=np.hypot(p.u10-p.u10_ref,p.v10-p.v10_ref)
                all_pairs.append(p[['season','day','time_UTC','point','comparison_reference','vector_difference']])
                for label,mask in [('HFX_ref_POSITIVO',b.HFX_W_m2>0),('HFX_ref_NO_POSITIVO',b.HFX_W_m2<=0),
                                   ('WS_ref_MENOR_2',b.WS10<2),('WS_ref_2_A_5',(b.WS10>=2)&(b.WS10<5)),('WS_ref_5_O_MAS',b.WS10>=5)]:
                    bb=b[mask];aa=a[a.time_UTC.isin(bb.time_UTC)]
                    if len(bb)>1:spatial.append(dict(season=season,reference=ref,point=point,regime=label,**metrics(aa,bb)[0]))
                for day,aa in a.groupby('day'):
                    bb=b[b.day.eq(day)]
                    if len(aa)<23:continue
                    d,_=metrics(aa,bb)
                    daily.append(dict(season=season,day=day,reference=ref,point=point,expected_hours=day_hours(day),complete_day=len(aa)==day_hours(day),**d))
    csv('Contraste_espacial_estacional.csv',spatial);csv('Contraste_espacial_diario.csv',daily)
    csv('Contraste_vectorial_horario.csv',pd.concat(all_pairs))
    design=json.loads((TERNAS/'Diseno.json').read_text())
    regime=[]
    for (s,point,day),g in x.groupby(['season','point','day']):
        if len(g)!=day_hours(day):continue
        regime.append(dict(season=s,point=point,day=day,hours=len(g),u_mean=g.u10.mean(),v_mean=g.v10.mean(),
            T_mean=g.T2_C.mean(),speed_mean=g.WS10.mean(),HFX_mean=g.HFX_W_m2.mean(),PBLH_mean=g.PBLH_m.mean(),
            SWDOWN_mean=g.SWDOWN_W_m2.mean(),fraction_HFX_positive=(g.HFX_W_m2>0).mean(),
            fraction_WS_below2=(g.WS10<2).mean(),snow_fraction_mean=g.snow_fraction.mean(),albedo_mean=g.albedo.mean()))
    regime=pd.DataFrame(regime);csv('Regimen_diario_seis_puntos.csv',regime)
    analogue=[]
    features=['u_mean','v_mean','T_mean','PBLH_mean','fraction_HFX_positive']
    for proto in design['prototypes']:
        s,sc,source=proto['season'],proto['scenario'],proto['source_day']
        for point in ['Estacion_PC','Columna_MMIF']:
            g=regime[regime.season.eq(s)&regime.point.eq(point)].set_index('day')
            std=g[features].std(ddof=1)
            assert (std>0).all()
            distances=np.sqrt((((g[features]-g.loc[source,features])/std)**2).mean(axis=1).astype(float))
            comparison=distances[distances.index!=source]
            for target in design['civil_days'][s]:
                if target not in g.index:continue
                d=float(distances.loc[target])
                analogue.append(dict(season=s,scenario=sc,point=point,source_day=source,application_day=target,
                    standardized_RMS_distance=d,seasonal_rank_percentile=100*float((comparison<=d).mean()),
                    comparison_days=len(comparison),purpose='Descriptive model-state distance; not an admission cutoff or probability',
                    **{f'difference_{v}':float(g.loc[target,v]-g.loc[source,v]) for v in features}))
    csv('Contraste_regimen_origen_aplicacion.csv',analogue)
    # Existing vertical samples are independent of this seasonal surface extension.
    profiles=pd.read_csv(PRE/'WRF_perfiles_seis_puntos.csv')
    vertical=[]
    for (season,z),g in profiles.groupby(['season','z_AGL_m']):
        b=g[g.point.eq('Columna_MMIF')]
        for point in ['Estacion_PC']+RECEPTORS:
            p=g[g.point.eq(point)].merge(b,on='time_UTC',suffixes=('','_ref'),validate='one_to_one')
            vertical.append(dict(season=season,point=point,z_AGL_m=z,hours=len(p),
                vector_RMS=float(np.sqrt(np.mean((p.u-p.u_ref)**2+(p.v-p.v_ref)**2))),
                theta_RMS=float(np.sqrt(np.mean((p.theta_K-p.theta_K_ref)**2))),
                sample='18 previously selected critical hours in total; not full-season vertical coverage'))
    csv('Contraste_vertical_horas_criticas.csv',vertical)
    gaps={}
    for s,g in x.groupby('season'):
        ts=pd.DatetimeIndex(sorted(g.time_UTC.unique()))
        gaps[s]=[str(t) for t in pd.date_range(ts.min(),ts.max(),freq='h').difference(ts)]
    assert gaps=={'INVIERNO':['2017-08-15 00:00:00'],'VERANO':[]}
    save('Verificacion_analisis_superficie.json',dict(season_hours=x.groupby('season').time_UTC.nunique().to_dict(),missing_internal_UTC=gaps,
        rows=len(x),spatial_rows=len(spatial),daily_rows=len(daily),regime_rows=len(regime),
        source_sha256=receipt['csv_sha256'],physical_validation=False,regime_cutoffs='Descriptive only; no fitted admission threshold'))
    print(pd.DataFrame(spatial).query("reference == 'Columna_MMIF' and regime == 'TODAS'")[['season','point','hours','wind_vector_RMS','corr_u','corr_v','mean_direction_difference']].to_string(index=False),flush=True)


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('part',choices=['profiles','surface','all']);args=a.parse_args()
    if args.part in ['profiles','all']:profiles()
    if args.part in ['surface','all']:surface()
