"""Figures and evidence dossier for physical-transfer assessment."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
sys.path.insert(0,'C:/Users/dcitu/Documents/Codex/2026-10-19/es/work/python_deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analizar import ROOT,OUT,PRE,RECEPTORS,sha,save,csv


def fmt(value,n=2):return f'{float(value):.{n}f}'.replace('.',',')
def link(name):return (OUT/name).as_posix()
def main():
    figdir=OUT/'Figuras';figdir.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
        'axes.grid':True,'grid.alpha':.2,'savefig.facecolor':'white'})
    pts=pd.read_csv(PRE/'Ubicacion_puntos.csv').query("season=='VERANO'")
    terrain=np.load(PRE/'Malla_VERANO.npz')
    fig,ax=plt.subplots(figsize=(9,7),layout='constrained')
    contour=ax.contourf(terrain['lon'],terrain['lat'],terrain['HGT'],levels=np.arange(1500,6001,250),cmap='terrain',extend='both')
    offsets={'Estacion_PC':(-105,-20),'Columna_MMIF':(-100,-20),'Los Bronces':(12,8),'Piedra Carvajal':(12,6),'Sulfatos':(10,-8),'La Paloma':(10,8)}
    for p in pts.itertuples():
        ax.scatter(p.lon,p.lat,s=75 if p.point=='Columna_MMIF' else 42,c='black',marker='*' if p.point=='Columna_MMIF' else '^' if p.point=='Estacion_PC' else 'o',zorder=4)
        name={'Estacion_PC':'Estación DGA','Columna_MMIF':'Columna MMIF'}.get(p.point,p.point)
        ax.annotate(name,(p.lon,p.lat),xytext=offsets[p.point],textcoords='offset points',fontsize=10,
                    bbox=dict(facecolor='white',alpha=.85,edgecolor='none',pad=2),zorder=5)
    station=pts[pts.point.eq('Estacion_PC')].iloc[0];column=pts[pts.point.eq('Columna_MMIF')].iloc[0]
    ax.plot([station.lon,column.lon],[station.lat,column.lat],'--',color='#283d50',linewidth=1.5)
    distance=float(np.hypot(station.x_utm-column.x_utm,station.y_utm-column.y_utm)/1000)
    ax.text(-70.308,-33.190,f'{fmt(distance)} km',fontsize=11,bbox=dict(facecolor='white',alpha=.85,edgecolor='none'))
    ax.set_xlim(-70.33,-70.21);ax.set_ylim(-33.245,-33.13);ax.set_aspect(1/np.cos(np.deg2rad(-33.2)))
    ax.set_xlabel('Longitud');ax.set_ylabel('Latitud')
    ax.set_title('Estación, columna meteorológica y cuatro receptores\nRelieve representado por WRF (malla de 1 km)',loc='left',fontweight='bold')
    fig.colorbar(contour,ax=ax,label='Altitud del terreno WRF (m s.n.m.)',shrink=.85)
    fig.savefig(figdir/'Ubicaciones_y_terreno_WRF.png',dpi=180);fig.savefig(figdir/'Ubicaciones_y_terreno_WRF.svg');plt.close(fig)

    contrasts=pd.read_csv(OUT/'Contraste_espacial_estacional.csv')
    whole=contrasts.query("reference=='Columna_MMIF' and regime=='TODAS'")
    order=['Estacion_PC']+RECEPTORS
    fig,axs=plt.subplots(1,2,figsize=(11,5.5),layout='constrained',sharey=True)
    for season,color,offset in [('VERANO','#d57526',-.18),('INVIERNO','#32688a',.18)]:
        d=whole[whole.season.eq(season)].set_index('point').loc[order]
        for ax,col in zip(axs,['wind_vector_RMS','mean_direction_difference']):
            bars=ax.barh(np.arange(5)+offset,d[col],height=.32,color=color,label=season.capitalize())
            ax.bar_label(bars,labels=[fmt(v,1) for v in d[col]],padding=3,fontsize=9)
    axs[0].set_yticks(range(5),['Estación DGA']+RECEPTORS);axs[0].invert_yaxis()
    axs[0].set_xlabel('Diferencia vectorial RMS respecto de la columna (m/s)')
    axs[0].set_xlim(0,15.5);axs[0].set_title('Rapidez y dirección combinadas',loc='left')
    axs[1].set_xlabel('Diferencia angular media (°), con ambas rapideces ≥ 1 m/s')
    axs[1].set_xlim(0,80);axs[1].set_title('Orientación del viento',loc='left')
    axs[0].legend(loc='upper right')
    fig.suptitle('Contraste espacial en WRF: 2153 horas de verano y 2206 de invierno\nComparación entre puntos simulados; no es un error frente a observaciones',fontsize=13)
    fig.savefig(figdir/'Contraste_estacional_viento.png',dpi=180);fig.savefig(figdir/'Contraste_estacional_viento.svg');plt.close(fig)

    diagnostic=pd.read_csv(ROOT/'outputs/Cierre_cientifico_2026-11-05/Diagnostico_horario_128_comparaciones.csv')
    profiles=pd.read_csv(OUT/'Perfiles_ONSITE_episodios.csv',parse_dates=['time_UTC'])
    operator=pd.read_csv(OUT/'Diagnostico_operador_horario.csv')
    anchors=[('Los Bronces','2017-01-16','OBS_U'),('Piedra Carvajal','2017-02-20','OBS_U'),('Sulfatos','2017-01-12','OBS_V'),('La Paloma','2017-01-26','OBS_V')]
    summary=[]
    regime=pd.read_csv(OUT/'Contraste_regimen_origen_aplicacion.csv')
    prior=pd.read_csv(PRE/'Fichas_actualizadas_transferencia.csv')
    fig,axs=plt.subplots(2,2,figsize=(11,8),layout='constrained',sharey=True)
    for ax,(receptor,day,sc) in zip(axs.flat,anchors):
        d=diagnostic[(diagnostic.receptor==receptor)&(diagnostic.day==day)&(diagnostic.scenario==sc)&(diagnostic.pollutant=='MP10')].iloc[0]
        end=pd.Timestamp(d.peak_positive_delta_end_LST)
        utc=end+pd.Timedelta(hours=3)
        p=profiles[(profiles.scenario==sc)&(profiles.time_UTC==utc)].dropna(subset=['T_BASE','T_pert']).sort_values('z_m')
        p=p[p.z_m<=500]
        z=p.z_m.to_numpy();mid=(z[:-1]+z[1:])/2
        for field,label,color in [('T_BASE','BASE','#334e68'),('T_pert',sc,'#c65c18')]:
            gradient=1000*(np.diff(p[field])/np.diff(z)+9.80665/1004.)
            ax.plot(gradient,mid,'o-',markersize=3,color=color,label=label)
        op=operator[(operator.scenario==sc)&(operator.end_LST==str(end))].iloc[0]
        ax.axvline(0,color='#444',linestyle='--',linewidth=1)
        ax.axhline(op.mixing_height_ONSITE,color='#555',linestyle=':',linewidth=1)
        ax.set_ylim(0,620);ax.set_ylabel('Altura sobre el terreno de la columna (m)')
        ax.set_xlabel('Indicador seco dT/dz + g/cp (K/km)')
        ax.set_title(f'{receptor} · {day}\nHora de mayor incremento: {end.hour-1:02d}:00 civil',loc='left',fontweight='bold',fontsize=11)
        ax.legend(loc='best',fontsize=9)
        a=regime[(regime.scenario==sc)&(regime.application_day==day)&(regime.point=='Columna_MMIF')].iloc[0]
        old=prior[(prior.receptor==receptor)&(prior.pollutant=='MP10')].iloc[0]
        summary.append(dict(receptor=receptor,day=day,scenario=sc,source_day=a.source_day,
            regime_distance_percentile=a.seasonal_rank_percentile,regime_comparison_days=a.comparison_days,
            whole_summer_vector_RMS=float(whole[(whole.season=='VERANO')&(whole.point==receptor)].iloc[0].wind_vector_RMS),
            episode_vector_RMS=float(old.receptor_column_vector_RMS_m_s),critical_Wind_pert=d.WS_at_largest_increase,
            critical_Wind_BASE=d.BASE_WS_at_largest_increase,critical_ustar_BASE=op.BASE_ustar,critical_ustar_pert=op.ustar,
            critical_H_BASE=op.BASE_H,critical_H_pert=op.H,critical_zim_BASE=op.BASE_zim,critical_zim_pert=op.zim,
            critical_new_negative_layers=int(op.layers_positive_to_negative),
            conclusion='Empirical prescribed sensitivity; physical transfer not demonstrated by model coherence alone'))
    fig.suptitle('Efecto vertical de la terna en las horas dominantes de los cuatro episodios\nLínea punteada horizontal: MHGT de entrada; indicador seco aproximado, no observación',fontsize=12)
    fig.savefig(figdir/'Perfiles_criticos_ternas.png',dpi=180);fig.savefig(figdir/'Perfiles_criticos_ternas.svg');plt.close(fig)
    csv('Fichas_transferencia_cuatro_receptores.csv',summary)

    table='\n'.join('| '+ ' | '.join([name]+[fmt(whole[(whole.point==point)&(whole.season==s)].iloc[0].wind_vector_RMS) for s in ['VERANO','INVIERNO']])+' |'
        for point,name in [('Estacion_PC','Estación DGA')]+[(a,a) for a in RECEPTORS])
    stable='\n'.join('| '+' | '.join([q['receptor'],q['source_day'],q['day'],q['scenario'],fmt(q['regime_distance_percentile'],1),fmt(q['episode_vector_RMS'])])+' |' for q in summary)
    parameter_table='\n'.join('| '+' | '.join([q['receptor'],fmt(q['critical_Wind_BASE'])+' → '+fmt(q['critical_Wind_pert']),
        fmt(q['critical_ustar_BASE'],3)+' → '+fmt(q['critical_ustar_pert'],3),fmt(q['critical_H_BASE'],1)+' → '+fmt(q['critical_H_pert'],1),
        fmt(q['critical_zim_BASE'],0)+' → '+fmt(q['critical_zim_pert'],0)])+' |' for q in summary)
    report=f'''**Transferencia física desde Piedra Carvajal: evaluación de la evidencia disponible**

13 de noviembre de 2026.

La revisión sustenta el uso de las ternas como perturbaciones prescritas con amplitudes de origen empírico. La evidencia disponible no demuestra que la misma discrepancia pueda trasladarse sin cambios a todos los lugares, alturas y episodios. H1 y H2 conservan el respaldo numérico ya documentado y una interpretación física condicionada. La ausencia de validación de la transferencia no implica que se haya demostrado la imposibilidad de los escenarios.

**Alcance de la revisión**

Se extrajeron los campos superficiales WRF de ambas ventanas en la estación, la columna MMIF y los cuatro receptores. Se leyeron 458 archivos nativos sin modificarlos y se obtuvieron 26.166 filas, incluyendo los instantes iniciales necesarios para emparejamiento. Las 2.100 filas de la extracción anterior se reprodujeron dentro de 10⁻⁹ en los campos cotejados. Los hashes documentados corresponden a campos extraídos y productos, junto con tamaño y fecha de los archivos originales; no son hashes de todos los NetCDF completos.

Los contrastes usan 2.153 horas de verano y 2.206 de invierno después de retirar el instante inicial, que no representa un intervalo estudiado. Falta el instante WRF del 15 de agosto a las 00:00 UTC en la selección nativa disponible. No se interpoló ese hueco. El último día estival conserva 17 horas. Los análisis de regímenes diarios utilizan únicamente días civiles completos: 89 de verano y 91 de invierno, incluyendo el día civil de 23 horas del cambio de horario y excluyendo el día afectado por el hueco. Esta cobertura meteorológica difiere de las fechas comunes usadas para comparar concentraciones.

Se auditó también el operador vertical en 2.151 horas procesadas válidas por terna estival y 2.205 horas de la terna invernal. Entre los instantes nativos extraídos, no entran en ese diagnóstico procesado el 3 de febrero y el 3 de marzo a las 23:00 UTC, y el 15 de agosto a las 01:00 UTC. El inventario de cobertura figura en `Verificacion_entrega.json`; no se rellenaron esas horas. Las comparaciones con concentración se restringen a los episodios ya calculados. Esta etapa ejecutó cero simulaciones nuevas de WRF, AERMET o AERMOD.

**Qué documenta la DGA**

La hoja Nacional de `Informe_Yerba_Loca.xlsx`, celdas B13:S14, identifica la estación 05721017, su instalación el 21 de abril de 2011, coordenadas E 381277 / N 6323409 y altitud de 3253 m. R14 enumera temperatura horaria y otros parámetros; S14 menciona termómetro, higrotermógrafo, actinógrafo y estación automática M.R.I. No se especifican el huso horario, la ventana de integración ni las alturas de los sensores. El parámetro denominado «ALTURA» no identifica la altura de instalación del termómetro o anemómetro. La ficha tampoco detalla un instrumento de viento; esto caracteriza el contenido de la ficha y no invalida por sí solo las series descargadas.

La respuesta `31653.pdf` remite a la información adjunta. Se confirmó con Daniel que ambos archivos constituyen todos los antecedentes de la solicitud. El acceso automatizado a la [página DGA-SAT indicada](https://snia.mop.gob.cl/dgasat/pages/dgasat_param/dgasat_param.jsp?param=1) devolvió 403; no se atribuyen al portal metadatos que no pudieron verificarse. La hipótesis de reloj civil sigue siendo una hipótesis de trabajo. La frecuencia nominal horaria de temperatura no permite deducir si cada valor es instantáneo o un promedio, ni el soporte temporal del viento.

**Transferencia horizontal**

La estación y la columna están separadas {fmt(distance)} km. La diferencia entre la cota de la columna y la altitud documental de la estación es de 216,6 m. Además, WRF representa el terreno de la estación a 3498,3 m: unos 245,3 m sobre la altitud de la ficha. Esta diferencia puede contribuir a la discrepancia térmica y a la exposición representada. No se aplicó una corrección automática por gradiente adiabático, porque la estratificación real no está acreditada para cada hora.

![Ubicaciones]({link('Figuras/Ubicaciones_y_terreno_WRF.png')})

El RMS de la diferencia vectorial de viento entre cada punto y la columna se calcula como la raíz de la media de [(u_punto − u_columna)² + (v_punto − v_columna)²]. Resume diferencias de rapidez y orientación entre puntos simulados; no mide un error frente a observaciones:

| Punto | Verano (m/s) | Invierno (m/s) |
|---|---:|---:|
{table}

![Contraste estacional]({link('Figuras/Contraste_estacional_viento.png')})

La columna se aproxima más al viento WRF de Los Bronces. La Paloma presenta las mayores diferencias en invierno. La temperatura de la estación y la columna tiene correlaciones cercanas a 0,98, pero la correlación entre campos no demuestra igualdad de sus errores. En viento, al retirar la media de cada día, la correlación de la componente v entre estación y columna desciende a 0,43 en verano y 0,38 en invierno. La coincidencia de la variación de varios días puede coexistir con diferencias de circulación dentro del día.

La justificación técnica exige distinguir variables y alturas. La guía MMIF recomienda evaluar observación y modelo emparejados en espacio y tiempo, juzgar la representatividad por variable y seleccionar una celda que represente el dominio. Contempla varias celdas cuando una sola no basta. Estas recomendaciones orientan el diagnóstico y no constituyen una certificación local ni una obligación adicional de legislación chilena. [EPA, guía MMIF, 2024, secciones 2.3.1 y 3.2.4](https://gaftp.epa.gov/aqmg/SCRAM/models/related/mmif/MMIF_Guidance.pdf).

Un estudio con trece torres muestra que la representatividad depende de la distancia, el promedio temporal y las condiciones atmosféricas. Su terreno es casi plano y su período es corto, por lo que sus distancias y errores no se trasladaron como umbrales al caso andino. Se utilizó como fundamento para desagregar el diagnóstico por condiciones meteorológicas. [De Wekker et al., 2026](https://doi.org/10.3390/atmos17070630).

**Transferencia entre días**

Se comparó el día de origen de cada terna con sus días de aplicación mediante cinco descriptores WRF: medias de u, v, temperatura y altura de mezcla, y fracción de horas con flujo de calor sensible positivo. Cada diferencia se dividió por la desviación estándar estacional del descriptor y se calculó su media cuadrática. Los cinco descriptores reciben igual peso. Esta es una distancia diagnóstica retrospectiva, sin umbral de admisión ni probabilidades asignadas.

El percentil siguiente ubica la distancia del día de aplicación dentro de las distancias de todos los otros días completos respecto del mismo origen, en la columna MMIF. Un percentil menor indica mayor semejanza según esos cinco descriptores.

| Receptor del episodio | Origen | Aplicación | Terna | Percentil de distancia | RMS receptor–columna en el episodio (m/s) |
|---|---|---|---|---:|---:|
{stable}

El régimen del 12 de enero, usado en Sulfatos con OBS_V, se aproxima más a su día de origen que el régimen del 20 de febrero a su origen bajo OBS_U. El contraste aporta una justificación temporal relativa para el primer caso, pero no acredita la transferencia vertical o espacial. En invierno, el 9 de julio se ubica aproximadamente en el percentil 66 de distancia respecto del 2 de julio en la columna. Los resultados completos incluyen todos los días de aplicación de las tres ternas, no solo los episodios que incrementaron la concentración.

**Transferencia vertical y procesamiento**

Se verificó que la perturbación sigue la función cúbica de atenuación definida, conserva los campos del encabezado ONSITE y deja intactos los niveles sobre la altura de mezcla de entrada. El incremento es completo cerca de 2 m para temperatura y de 10 m para viento, y se anula al alcanzar MHGT. La diferencia térmica DT01 también coincide con las temperaturas escritas. Estos controles acreditan la implementación del operador.

La función reduce la perturbación en altura y modifica los gradientes. Como diagnóstico se calculó dT/dz + g/cp entre niveles, hasta 500 m. Es un indicador seco aproximado de estratificación, no una medición de temperatura potencial ni una prueba completa de estabilidad dinámica. Los cambios de signo que no superan la resolución del archivo se excluyen del recuento. Bajo OBS_U de verano aparecen nuevas capas con indicador negativo en 1504 de 2151 horas; bajo OBS_V, en 1274. Esas cifras no son porcentajes de atmósferas físicamente imposibles: señalan que la atenuación térmica tiene consecuencias que deben considerarse al interpretar el experimento.

![Perfiles]({link('Figuras/Perfiles_criticos_ternas.png')})

El encabezado ONSITE conserva flujos y altura de mezcla de entrada, mientras AERMET recalcula variables dependientes. En la tabla, u* es la velocidad de fricción, H es el flujo de calor sensible y zim es la altura de mezcla mecánica calculada por AERMET; zim no equivale a MHGT de entrada. En la hora de mayor incremento de concentración MP10 de cada episodio se obtuvo:

| Receptor | Rapidez BASE → terna (m/s) | u* BASE → terna (m/s) | H BASE → terna (W/m²) | zim BASE → terna (m) |
|---|---:|---:|---:|---:|
{parameter_table}

Por ejemplo, en Los Bronces, la rapidez baja de 3,21 a 0,46 m/s y u* de 0,165 a 0,043 m/s. El aumento de concentración responde a una cadena de procesamiento y no solo a la adición de un vector. La atmósfera perturbada no se reintegra con WRF; por ello, los controles de formato y rangos no demuestran conservación dinámica o energética del estado completo.

**Qué puede y qué no puede justificarse**

La discrepancia disponible es `e_estación = observación_estación − WRF_estación`. La perturbación supone `Δcolumna(z,t) = w(z,t) · e_día_origen`. La igualdad entre la discrepancia de estación y el error de la columna no se observa: falta una referencia independiente en la columna. El contraste `WRF_columna − WRF_estación` mide heterogeneidad del modelo y no permite identificar por sí solo la covarianza de sus errores.

| Aspecto | Decisión basada en esta revisión |
|---|---|
| Amplitudes conjuntas de las ternas | Su origen empírico y reproducción están documentados. |
| Implementación y respuesta de AERMET | Verificadas. Se cuantificaron los cambios verticales y de variables dependientes. |
| Transferencia uniforme a todos los puntos | No demostrada. Los campos muestran diferencias espaciales y de exposición. |
| Aplicación en cualquier día | No sustentada. La semejanza entre día de origen y aplicación cambia entre episodios. |
| Validación dinámica y del error espacial | No resuelta por los datos disponibles. |
| H1 y H2 | Respaldo numérico con interpretación física condicionada a los supuestos de transferencia. |

Los resultados se conservan como análisis de sensibilidad prescrito. Para elevar el alcance a una perturbación local validada se necesita evidencia del reloj y de los sensores, y un contraste independiente del viento y del perfil en la zona de emisión y transporte. Esa necesidad corresponde a la afirmación más fuerte de validación; no impide presentar los resultados actuales con su alcance explícito.

Una continuación computacional acotada podría comparar meteorologías nativas de varias celdas WRF con las mismas fuentes y horas, para medir cuánto dependen los resultados de la columna elegida. Ese ensayo resolvería una sensibilidad de representación, pero tampoco sustituiría observaciones independientes. No se inició una nueva campaña de dispersión ni la extensión de 506 casos, porque repetir las mismas hipótesis en más fechas no resolvería la transferencia.

**Documentación y reproducción**

La carpeta contiene el protocolo, la extracción estacional, sus hashes, contrastes por régimen y día, los perfiles de los episodios, fichas de los cuatro receptores y el cotejo de la ficha DGA. Los comandos `analizar.py profiles`, `analizar.py surface` e `informe.py`, ubicados en `work/transferencia_fisica_20261113`, realizan el posproceso. `extraer.py` lee los WRF originales y reutiliza sus extracciones verificadas si ya existen. Los datos originales permanecen intactos.
'''
    (OUT/'Informe_transferencia_fisica.md').write_text(report,encoding='utf8')
    request='''Se solicita complementar la información de la estación 05721017, Estero Yerba Loca en Piedra Carvajal, para el período diciembre de 2016 a septiembre de 2017, indicando: (1) referencia horaria de las marcas descargadas desde DGA-SAT y tratamiento del horario de verano; (2) si los registros de temperatura, rapidez y dirección del viento corresponden a valores instantáneos o promedios, con sus intervalos de integración y significado del minuto :49; (3) altura sobre el terreno, modelo y configuración de los sensores de temperatura y viento durante ese período; y (4) cambios de instrumentación o ubicación y antecedentes de control de calidad disponibles. La solicitud complementa la respuesta AM006T0031653 y su Informe Nacional. Estos datos permiten distinguir discrepancias del modelo de diferencias de altura, exposición y soporte temporal.\n'''
    (OUT/'Solicitud_complementaria_DGA_borrador.txt').write_text(request,encoding='utf8')
    save('Resumen_revision.json',dict(station_to_column_distance_km=distance,field_hours={'VERANO':2153,'INVIERNO':2206},
        all_four_receptors_included=True,full_physical_validation=False,new_models_run=0,
        meteorological_regime_distance='Retrospective standardized diagnostic, not admission cutoff',
        figures=[p.name for p in sorted(figdir.glob('*.png'))],external_message_sent=False))
    print('REPORT_AND_THREE_FIGURES_READY')


if __name__=='__main__':main()
