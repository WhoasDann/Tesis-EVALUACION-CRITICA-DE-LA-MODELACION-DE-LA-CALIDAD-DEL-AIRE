"""Read existing WRF surface fields throughout both study windows; resumable."""
from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from netCDF4 import Dataset, chartostring

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/Transferencia_fisica_2026-11-13'
EX=OUT/'Extraccion'
OLD=Path('C:/Users/dcitu/Documents/Codex/2026-10-08/hem')
PRE=ROOT/'outputs/Cierre_cientifico_2026-11-05/Transferencia_WRF'
sys.path.insert(0,str(OLD/'outputs/Biblioteca_Tesis'))
from tesis.validacion import bilineal,rotar_a_tierra


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf8')


def main():
    EX.mkdir(parents=True,exist_ok=True)
    protocol=dict(scope='Physical transfer diagnostics across native WRF seasonal windows; no new atmospheric or dispersion runs.',
        created_utc=datetime.now(timezone.utc).isoformat(),date_local='2026-11-13',
        variables=['T2','U10','V10','COSALPHA','SINALPHA','PBLH','PSFC','HFX','UST','SWDOWN','ALBEDO','SNOWC'],
        points='Same six audited locations as 5 November extraction; rotation before bilinear interpolation.',
        intended_tests=['Simultaneous vector RMS, u/v correlation and direction differences; stratification by heat flux sign and wind speed, not concentration.',
            'Full common hours and day-scale anomalies reported separately; no iid probability claims.',
            'Selected donor and application days contrasted against full seasonal population, retaining all four receptors.',
            'PFL changes, temperature gradients, wind shear and attenuation support checked on existing scenarios.',
            'Model-to-model spatial coherence does not establish spatial covariance of model errors.'],
        acceptance='No numerical threshold chosen to confer physical validation. Decision separates empirical amplitudes, conditional consistency and missing independent evidence.',
        no_old_queues=True,WRF_modified=False,new_AERMOD_runs=0)
    if not (OUT/'Protocolo.json').exists():save(OUT/'Protocolo.json',protocol)
    locations=pd.read_csv(PRE/'Ubicacion_puntos.csv')
    sources=[]
    for season,start,end in [('VERANO','2016-12-21 03:00','2017-03-21 03:00'),('INVIERNO','2017-06-21 04:00','2017-09-21 03:00')]:
        start,end=pd.Timestamp(start),pd.Timestamp(end)
        folder=Path('D:/Tesis_Dan/wrfoutVer' if season=='VERANO' else 'D:/Tesis_Dan/wrfoutInv')
        assert folder.exists(),folder
        selection={}
        if season=='INVIERNO':
            selection={x['archivo']:x for x in read(OLD/'outputs/BASE_invierno_2026-10-24/Seleccion_WRF.json')['archivos']}
            paths=[folder/name for name in selection]
        else:
            paths=[p for p in sorted(folder.glob('wrfout_d03_*')) if start.normalize()-pd.Timedelta(days=1)<=pd.Timestamp(p.name[11:21])<=end.normalize()]
        for path in paths:
            cache=EX/(season+'_'+path.name+'.csv')
            audit=cache.with_suffix('.json')
            st=path.stat()
            if audit.exists():
                a=read(audit)
                assert a['bytes']==st.st_size and a['mtime_ns']==st.st_mtime_ns and a['csv_sha256']==sha(cache)
                sources.append(a)
                continue
            with Dataset(path) as n:
                n.set_auto_mask(False)
                if season=='INVIERNO':
                    sel=selection[path.name]
                    assert st.st_size==sel['bytes'] and st.st_mtime_ns==sel['mtime_ns']
                    ts=pd.to_datetime(sel['times_exportados'],format='%Y-%m-%d_%H:%M:%S')
                    chosen=[(i,t) for i,t in zip(sel['indices_seleccionados'],ts) if start<=t<=end]
                else:
                    ts=pd.to_datetime(chartostring(n['Times'][:]).tolist(),format='%Y-%m-%d_%H:%M:%S')
                    chosen=[(i,t) for i,t in enumerate(ts) if start<=t<=end]
                if not chosen:continue
                assert int(n.GRID_ID)==3 and float(n.DX)==1000 and float(n.DY)==1000
                lat=np.asarray(n['XLAT'][0],float);lon=np.asarray(n['XLONG'][0],float)
                column=locations[locations.season.eq(season)&locations.point.eq('Columna_MMIF')].iloc[0]
                assert abs(lat[43,42]-column.lat)<1e-7 and abs(lon[43,42]-column.lon)<1e-7
                indices=[i for i,t in chosen]
                arr={k:np.asarray(n[k][indices],float) for k in protocol['variables']}
                u,v=rotar_a_tierra(arr['U10'],arr['V10'],arr['COSALPHA'],arr['SINALPHA'])
                xtbase=pd.Timestamp(str(n['XTIME'].units).split('since ')[1].replace('_',' '))
                rows=[];offsets=[]
                for j,(i,t) in enumerate(chosen):
                    offset=(xtbase+pd.Timedelta(minutes=float(n['XTIME'][i]))-t).total_seconds()
                    assert abs(offset)<=10,(path,t,offset)
                    offsets.append(offset)
                    for point in locations[locations.season.eq(season)].itertuples():
                        x,y=point.fx,point.fy
                        uu,vv=float(bilineal(u[j],x,y)),float(bilineal(v[j],x,y))
                        row=dict(season=season,point=point.point,time_UTC=str(t),u10=uu,v10=vv,WS10=float(np.hypot(uu,vv)),
                            WD10=float(np.degrees(np.arctan2(-uu,-vv))%360),HGT_m=point.HGT_m,
                            source_file=path.name,source_index=i,actual_offset_s=offset)
                        for original,field in [('T2','T2_K'),('PBLH','PBLH_m'),('PSFC','PSFC_Pa'),('HFX','HFX_W_m2'),
                            ('UST','UST_m_s'),('SWDOWN','SWDOWN_W_m2'),('ALBEDO','albedo'),('SNOWC','snow_fraction')]:
                            row[field]=float(bilineal(arr[original][j],x,y))
                        row['T2_C']=row.pop('T2_K')-273.15
                        rows.append(row)
                frame=pd.DataFrame(rows)
                assert np.isfinite(frame.select_dtypes('number')).all().all()
                frame.to_csv(cache,index=False)
                a=dict(season=season,path=str(path),bytes=st.st_size,mtime_ns=st.st_mtime_ns,rows=len(rows),
                    selected_indices=indices,nominal_times=[str(t) for i,t in chosen],offsets_s=offsets,
                    fields_float64_sha256={k:hashlib.sha256(x.tobytes()).hexdigest() for k,x in arr.items()},
                    csv=cache.name,csv_sha256=sha(cache),hash_scope='Extracted arrays and CSV, not complete native file')
                save(audit,a);sources.append(a)
            if len(sources)%15==0: print(json.dumps(dict(files=len(sources),last=path.name)),flush=True)
    full=pd.concat([pd.read_csv(EX/a['csv']) for a in sources],ignore_index=True).sort_values(['season','point','time_UTC'])
    assert not full.duplicated(['season','point','time_UTC']).any()
    previous=pd.read_csv(PRE/'WRF_superficie_seis_puntos.csv')
    match=full.merge(previous,on=['season','point','time_UTC'],suffixes=('','_old'),validate='one_to_one')
    assert len(match)==len(previous)==2100
    diffs={k:float(abs(match[k]-match[k+'_old']).max()) for k in ['u10','v10','T2_C','PBLH_m','HFX_W_m2','PSFC_Pa','UST_m_s']}
    assert max(diffs.values())<1e-9
    destination=OUT/'Superficie_estacional_seis_puntos.csv'
    full.to_csv(destination,index=False)
    save(OUT/'Trazabilidad_extraccion.json',sources)
    stats={s:dict(hours=int(d.time_UTC.nunique()),rows=len(d),first=d.time_UTC.min(),last=d.time_UTC.max()) for s,d in full.groupby('season')}
    save(OUT/'Recepcion_extraccion.json',dict(status='VERIFIED',rows=len(full),seasons=stats,
        files=len(sources),previous_rows_reproduced=len(match),max_previous_differences=diffs,
        csv_sha256=sha(destination),models_run=0,source_files_modified=False))
    print(json.dumps(stats),flush=True)


if __name__=='__main__':main()
