"""Independent arithmetic and provenance checks for the delivered assessment."""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/Transferencia_fisica_2026-11-13'
PRE = ROOT / 'outputs/Cierre_cientifico_2026-11-05/Transferencia_WRF'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(name):
    return json.loads((OUT / name).read_text(encoding='utf8'))


def main():
    x = pd.read_csv(OUT / 'Superficie_estacional_seis_puntos.csv', parse_dates=['time_UTC'])
    assert len(x) == 26166 and not x.duplicated(['season', 'point', 'time_UTC']).any()
    assert np.isfinite(x.select_dtypes('number')).all().all()
    assert sha(OUT / 'Superficie_estacional_seis_puntos.csv') == read('Recepcion_extraccion.json')['csv_sha256']
    old = pd.read_csv(PRE / 'WRF_superficie_seis_puntos.csv', parse_dates=['time_UTC'])
    match = x.merge(old, on=['season', 'point', 'time_UTC'], suffixes=('', '_old'), validate='one_to_one')
    assert len(match) == len(old) == 2100
    previous_error = max(float(abs(match[c] - match[c + '_old']).max())
                         for c in ['u10', 'v10', 'T2_C', 'PBLH_m', 'HFX_W_m2', 'PSFC_Pa', 'UST_m_s'])
    assert previous_error < 1e-9
    trace = read('Trazabilidad_extraccion.json')
    assert len(trace) == 458
    for source in trace:
        assert sha(OUT / 'Extraccion' / source['csv']) == source['csv_sha256']
        p = Path(source['path'])
        st = p.stat()
        assert (st.st_size, st.st_mtime_ns) == (source['bytes'], source['mtime_ns'])
    dga = read('Cotejo_ficha_DGA.json')
    assert sha(Path(dga['file'])) == dga['sha256']
    input_hashes = {}
    for audit in read('Verificacion_operador.json'):
        for path, expected in audit['inputs'].items():
            input_hashes[path] = expected
    for path, expected in input_hashes.items():
        assert sha(Path(path)) == expected, path

    # Select endpoints directly, independently of the analysis date conversion.
    s = x[((x.season == 'VERANO') & (x.time_UTC > '2016-12-21 03:00:00')) |
          ((x.season == 'INVIERNO') & (x.time_UTC > '2017-06-21 04:00:00'))].copy()
    spatial = pd.read_csv(OUT / 'Contraste_espacial_estacional.csv').query("regime == 'TODAS'")
    deviations = []
    for r in spatial.itertuples():
        group = s[s.season.eq(r.season)]
        pivot = group.pivot(index='time_UTC', columns='point', values=['u10', 'v10'])
        a = pivot.loc[:, [('u10', r.point), ('v10', r.point)]].to_numpy()
        b = pivot.loc[:, [('u10', r.reference), ('v10', r.reference)]].to_numpy()
        rms = np.sqrt(np.sum((a-b)**2) / len(a))
        ok = (np.linalg.norm(a, axis=1) >= 1) & (np.linalg.norm(b, axis=1) >= 1)
        # atan2 of cross and dot products avoids the stored wind-direction field.
        angle = np.degrees(np.arctan2(abs(a[:, 0]*b[:, 1] - a[:, 1]*b[:, 0]), np.sum(a*b, axis=1)))
        deviations.append(dict(season=r.season, point=r.point, reference=r.reference,
                               RMS_error=float(abs(rms-r.wind_vector_RMS)),
                               angular_error=float(abs(angle[ok].mean()-r.mean_direction_difference))))
        assert len(a) == r.hours and ok.sum() == r.direction_hours
    assert max(r['RMS_error'] for r in deviations) < 1e-10
    assert max(r['angular_error'] for r in deviations) < 1e-10

    days = pd.read_csv(OUT / 'Regimen_diario_seis_puntos.csv')
    assert not days.duplicated(['season', 'point', 'day']).any()
    counts = days[days.point.eq('Columna_MMIF')].groupby('season').day.nunique().to_dict()
    assert counts == {'INVIERNO': 91, 'VERANO': 89}
    assert '2017-08-14' not in set(days.day) and '2017-03-20' not in set(days.day)
    assert len(days[days.day.eq('2017-08-13')]) == 6
    assert set(days[days.day.eq('2017-08-13')].hours) == {23}
    for row in days.itertuples():
        g = s[(s.season == row.season) & (s.point == row.point)]
        civil_start = (g.time_UTC-pd.Timedelta(hours=1)).dt.tz_localize('UTC').dt.tz_convert('America/Santiago')
        assert (civil_start.dt.strftime('%Y-%m-%d') == row.day).sum() == row.hours

    op = pd.read_csv(OUT / 'Diagnostico_operador_horario.csv', parse_dates=['time_UTC'])
    coverage = []
    for (season, scenario), g in op.groupby(['season', 'scenario']):
        native = pd.DatetimeIndex(s[s.season.eq(season)].time_UTC.unique())
        processed = pd.DatetimeIndex(g.time_UTC.unique())
        coverage.append(dict(season=season, scenario=scenario, native_hours=len(native), processed_hours=len(processed),
                             native_not_processed=[str(t) for t in native.difference(processed)],
                             processed_not_native=[str(t) for t in processed.difference(native)]))
    neg = op.groupby(['season', 'scenario']).any_positive_to_negative.sum().to_dict()
    assert neg[('VERANO', 'OBS_U')] == 1504 and neg[('VERANO', 'OBS_V')] == 1274
    assert neg[('INVIERNO', 'OBS_U')] == 0
    figures = list((OUT / 'Figuras').glob('*.png'))
    assert len(figures) == 3
    report = (OUT / 'Informe_transferencia_fisica.md').read_text(encoding='utf8')
    for target in re.findall(r'\]\((C:/[^)]+)\)', report):
        assert Path(target).is_file()
    fichas = pd.read_csv(OUT / 'Fichas_transferencia_cuatro_receptores.csv')
    assert set(fichas.receptor) == {'Los Bronces', 'Piedra Carvajal', 'Sulfatos', 'La Paloma'}
    assert set(fichas.regime_comparison_days) == {88}
    regime = pd.read_csv(OUT / 'Contraste_regimen_origen_aplicacion.csv')
    winter = regime.query("season=='INVIERNO' and point=='Columna_MMIF' and application_day=='2017-07-09'").iloc[0]
    assert round(winter.seasonal_rank_percentile) == 66
    receipt = dict(status='VERIFIED_ASSESSMENT_WITH_EXPLICIT_LIMITATIONS', date_local='2026-11-13',
                   assessment_complete=True, full_physical_validation=False, new_model_runs=0,
                   external_messages_sent=False, manuscript_edited=False, github_published=False,
                   native_files_checked_size_mtime=len(trace), extracted_file_hashes_checked=len(trace),
                   previous_rows_reproduced=len(match), previous_max_error=previous_error,
                   existing_meteorology_hashes_checked=len(input_hashes), dga_workbook_hash_verified=True,
                   extracted_rows=len(x), complete_civil_days=counts, independent_spatial_checks=deviations,
                   processing_coverage=coverage, winter_july9_regime_percentile=float(winter.seasonal_rank_percentile),
                   artifacts={str(p.relative_to(ROOT)):sha(p) for p in sorted(OUT.glob('*')) if p.is_file() and p.name != 'Verificacion_entrega.json'},
                   figures={p.name:sha(p) for p in sorted((OUT/'Figuras').iterdir()) if p.is_file()},
                   scripts={p.name:sha(p) for p in sorted(Path(__file__).parent.glob('*.py'))})
    (OUT / 'Verificacion_entrega.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({k: receipt[k] for k in ['status', 'complete_civil_days', 'processing_coverage', 'winter_july9_regime_percentile']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
