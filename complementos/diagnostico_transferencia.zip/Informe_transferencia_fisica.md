**Transferencia física desde Piedra Carvajal: evaluación de la evidencia disponible**

13 de noviembre de 2026.

La revisión sustenta el uso de las ternas como perturbaciones prescritas con amplitudes de origen empírico. La evidencia disponible no demuestra que la misma discrepancia pueda trasladarse sin cambios a todos los lugares, alturas y episodios. H1 y H2 conservan el respaldo numérico ya documentado y una interpretación física condicionada. La ausencia de validación de la transferencia no implica que se haya demostrado la imposibilidad de los escenarios.

**Alcance de la revisión**

Se extrajeron los campos superficiales WRF de ambas ventanas en la estación, la columna MMIF y los cuatro receptores. Se leyeron 458 archivos nativos sin modificarlos y se obtuvieron 26.166 filas, incluyendo los instantes iniciales necesarios para emparejamiento. Las 2.100 filas de la extracción anterior se reprodujeron dentro de 10⁻⁹ en los campos cotejados. Los hashes documentados corresponden a campos extraídos y productos, junto con tamaño y fecha de los archivos originales; no son hashes de todos los NetCDF completos.

Los contrastes usan 2.153 horas de verano y 2.206 de invierno después de retirar el instante inicial, que no representa un intervalo estudiado. Falta el instante WRF del 15 de agosto a las 00:00 UTC en la selección nativa disponible. No se interpoló ese hueco. El último día estival conserva 17 horas. Los análisis de regímenes diarios utilizan únicamente días civiles completos: 89 de verano y 91 de invierno, incluyendo el día civil de 23 horas del cambio de horario y excluyendo el día afectado por el hueco. Esta cobertura meteorológica difiere de las fechas comunes usadas para comparar concentraciones.

Se auditó también el operador vertical en 2.151 horas procesadas válidas por terna estival y 2.205 horas de la terna invernal. Entre los instantes nativos extraídos, no entran en ese diagnóstico procesado el 3 de febrero y el 3 de marzo a las 23:00 UTC, y el 15 de agosto a las 01:00 UTC. El inventario de cobertura figura en `Verificacion_entrega.json`; no se rellenaron esas horas. Las comparaciones con concentración se restringen a los episodios ya calculados. Esta etapa ejecutó cero simulaciones nuevas de WRF, AERMET o AERMOD.

**Qué documenta la DGA**

La hoja Nacional de `Informe_Yerba_Loca.xlsx`, celdas B13:S14, identifica la estación 05721017, su instalación el 21 de abril de 2011, coordenadas E 381277 / N 6323409 y altitud de 3253 m. R14 enumera temperatura horaria y otros parámetros; S14 menciona termómetro, higrotermógrafo, actinógrafo y estación automática M.R.I. No se especifican el huso horario, la ventana de integración ni las alturas de los sensores. El parámetro denominado «ALTURA» no identifica la altura de instalación del termómetro o anemómetro. La ficha tampoco detalla un instrumento de viento; esto caracteriza el contenido de la ficha y no invalida por sí solo las series descargadas.

La respuesta `31653.pdf` remite a la información adjunta. Se confirmó con Daniel que ambos archivos constituyen todos los antecedentes de la solicitud. El acceso automatizado a la [página DGA-SAT indicada](https://snia.mop.gob.cl/dgasat/pages/dgasat_param/dgasat_param.jsp?param=1) devolvió 403; no se atribuyen al portal metadatos que no pudieron verificarse. La hipótesis de reloj civil sigue siendo una hipótesis de trabajo. La frecuencia nominal horaria de temperatura no permite deducir si cada valor es instantáneo o un promedio, ni el soporte temporal del viento.

**Transferencia horizontal**

La estación y la columna están separadas 7,50 km. La diferencia entre la cota de la columna y la altitud documental de la estación es de 216,6 m. Además, WRF representa el terreno de la estación a 3498,3 m: unos 245,3 m sobre la altitud de la ficha. Esta diferencia puede contribuir a la discrepancia térmica y a la exposición representada. No se aplicó una corrección automática por gradiente adiabático, porque la estratificación real no está acreditada para cada hora.

![Ubicaciones](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Transferencia_fisica_2026-11-13/Figuras/Ubicaciones_y_terreno_WRF.png)

El RMS de la diferencia vectorial de viento entre cada punto y la columna se calcula como la raíz de la media de [(u_punto − u_columna)² + (v_punto − v_columna)²]. Resume diferencias de rapidez y orientación entre puntos simulados; no mide un error frente a observaciones:

| Punto | Verano (m/s) | Invierno (m/s) |
|---|---:|---:|
| Estación DGA | 4,37 | 7,27 |
| Los Bronces | 1,47 | 2,19 |
| Piedra Carvajal | 4,60 | 8,07 |
| Sulfatos | 5,02 | 7,52 |
| La Paloma | 5,77 | 12,87 |

![Contraste estacional](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Transferencia_fisica_2026-11-13/Figuras/Contraste_estacional_viento.png)

La columna se aproxima más al viento WRF de Los Bronces. La Paloma presenta las mayores diferencias en invierno. La temperatura de la estación y la columna tiene correlaciones cercanas a 0,98, pero la correlación entre campos no demuestra igualdad de sus errores. En viento, al retirar la media de cada día, la correlación de la componente v entre estación y columna desciende a 0,43 en verano y 0,38 en invierno. La coincidencia de la variación de varios días puede coexistir con diferencias de circulación dentro del día.

La justificación técnica exige distinguir variables y alturas. La guía MMIF recomienda evaluar observación y modelo emparejados en espacio y tiempo, juzgar la representatividad por variable y seleccionar una celda que represente el dominio. Contempla varias celdas cuando una sola no basta. Estas recomendaciones orientan el diagnóstico y no constituyen una certificación local ni una obligación adicional de legislación chilena. [EPA, guía MMIF, 2024, secciones 2.3.1 y 3.2.4](https://gaftp.epa.gov/aqmg/SCRAM/models/related/mmif/MMIF_Guidance.pdf).

Un estudio con trece torres muestra que la representatividad depende de la distancia, el promedio temporal y las condiciones atmosféricas. Su terreno es casi plano y su período es corto, por lo que sus distancias y errores no se trasladaron como umbrales al caso andino. Se utilizó como fundamento para desagregar el diagnóstico por condiciones meteorológicas. [De Wekker et al., 2026](https://doi.org/10.3390/atmos17070630).

**Transferencia entre días**

Se comparó el día de origen de cada terna con sus días de aplicación mediante cinco descriptores WRF: medias de u, v, temperatura y altura de mezcla, y fracción de horas con flujo de calor sensible positivo. Cada diferencia se dividió por la desviación estándar estacional del descriptor y se calculó su media cuadrática. Los cinco descriptores reciben igual peso. Esta es una distancia diagnóstica retrospectiva, sin umbral de admisión ni probabilidades asignadas.

El percentil siguiente ubica la distancia del día de aplicación dentro de las distancias de todos los otros días completos respecto del mismo origen, en la columna MMIF. Un percentil menor indica mayor semejanza según esos cinco descriptores.

| Receptor del episodio | Origen | Aplicación | Terna | Percentil de distancia | RMS receptor–columna en el episodio (m/s) |
|---|---|---|---|---:|---:|
| Los Bronces | 2016-12-27 | 2017-01-16 | OBS_U | 61,4 | 0,31 |
| Piedra Carvajal | 2016-12-27 | 2017-02-20 | OBS_U | 89,8 | 3,97 |
| Sulfatos | 2017-01-18 | 2017-01-12 | OBS_V | 10,2 | 1,55 |
| La Paloma | 2017-01-18 | 2017-01-26 | OBS_V | 18,2 | 5,37 |

El régimen del 12 de enero, usado en Sulfatos con OBS_V, se aproxima más a su día de origen que el régimen del 20 de febrero a su origen bajo OBS_U. El contraste aporta una justificación temporal relativa para el primer caso, pero no acredita la transferencia vertical o espacial. En invierno, el 9 de julio se ubica aproximadamente en el percentil 66 de distancia respecto del 2 de julio en la columna. Los resultados completos incluyen todos los días de aplicación de las tres ternas, no solo los episodios que incrementaron la concentración.

**Transferencia vertical y procesamiento**

Se verificó que la perturbación sigue la función cúbica de atenuación definida, conserva los campos del encabezado ONSITE y deja intactos los niveles sobre la altura de mezcla de entrada. El incremento es completo cerca de 2 m para temperatura y de 10 m para viento, y se anula al alcanzar MHGT. La diferencia térmica DT01 también coincide con las temperaturas escritas. Estos controles acreditan la implementación del operador.

La función reduce la perturbación en altura y modifica los gradientes. Como diagnóstico se calculó dT/dz + g/cp entre niveles, hasta 500 m. Es un indicador seco aproximado de estratificación, no una medición de temperatura potencial ni una prueba completa de estabilidad dinámica. Los cambios de signo que no superan la resolución del archivo se excluyen del recuento. Bajo OBS_U de verano aparecen nuevas capas con indicador negativo en 1504 de 2151 horas; bajo OBS_V, en 1274. Esas cifras no son porcentajes de atmósferas físicamente imposibles: señalan que la atenuación térmica tiene consecuencias que deben considerarse al interpretar el experimento.

![Perfiles](C:/Users/dcitu/Documents/Codex/2026-10-26/ua/outputs/Transferencia_fisica_2026-11-13/Figuras/Perfiles_criticos_ternas.png)

El encabezado ONSITE conserva flujos y altura de mezcla de entrada, mientras AERMET recalcula variables dependientes. En la tabla, u* es la velocidad de fricción, H es el flujo de calor sensible y zim es la altura de mezcla mecánica calculada por AERMET; zim no equivale a MHGT de entrada. En la hora de mayor incremento de concentración MP10 de cada episodio se obtuvo:

| Receptor | Rapidez BASE → terna (m/s) | u* BASE → terna (m/s) | H BASE → terna (W/m²) | zim BASE → terna (m) |
|---|---:|---:|---:|---:|
| Los Bronces | 3,21 → 0,46 | 0,165 → 0,043 | -30,6 → -1,8 | 586 → 670 |
| Piedra Carvajal | 3,44 → 0,40 | 0,175 → 0,038 | -37,9 → -1,6 | 259 → 323 |
| Sulfatos | 0,74 → 0,69 | 0,084 → 0,081 | 130,4 → 130,6 | 154 → 175 |
| La Paloma | 1,89 → 1,38 | 0,165 → 0,133 | 210,6 → 210,8 | 161 → 117 |

Por ejemplo, en Los Bronces, la rapidez baja de 3,21 a 0,46 m/s y u* de 0,165 a 0,043 m/s. El aumento de concentración responde a una cadena de procesamiento y no solo a la adición de un vector. La atmósfera perturbada no se reintegra con WRF; por ello, los controles de formato y rangos no demuestran conservación dinámica o energética del estado completo.

**Qué puede y qué no puede justificarse**

La discrepancia disponible es `e_estación = observación_estación − WRF_estación`. La perturbación supone `Δcolumna(z,t) = w(z,t) · e_día_origen`. La igualdad entre la discrepancia de estación y el error de la columna no se observa: falta una referencia independiente en la columna. El contraste `WRF_columna − WRF_estación` mide heterogeneidad del modelo y no permite identificar por sí solo la covarianza de sus errores.

| Aspecto | Decisión basada en esta revisión |
|---|---|
| Amplitudes conjuntas de las ternas | Su origen empírico y reproducción están documentados. |
| Implementación y respuesta de AERMET | Verificadas. Se cuantificaron los cambios verticales y de variables dependientes. |
| Transferencia uniforme a todos los puntos | No demostrada. Los campos muestran diferencias espaciales y de exposición. |
| Aplicación en cualquier día | No sustentada. La semejanza entre día de origen y aplicación cambia entre episodios. |
| Validación dinámica y del error espacial | No resuelta por los datos disponibles. |
| H1 y H2 | Respaldo numérico con interpretación física condicionada a los supuestos de transferencia. |

Los resultados se conservan como análisis de sensibilidad prescrito. Para elevar el alcance a una perturbación local validada se necesita evidencia del reloj y de los sensores, y un contraste independiente del viento y del perfil en la zona de emisión y transporte. Esa necesidad corresponde a la afirmación más fuerte de validación; no impide presentar los resultados actuales con su alcance explícito.

Una continuación computacional acotada podría comparar meteorologías nativas de varias celdas WRF con las mismas fuentes y horas, para medir cuánto dependen los resultados de la columna elegida. Ese ensayo resolvería una sensibilidad de representación, pero tampoco sustituiría observaciones independientes. No se inició una nueva campaña de dispersión ni la extensión de 506 casos, porque repetir las mismas hipótesis en más fechas no resolvería la transferencia.

**Documentación y reproducción**

La carpeta contiene el protocolo, la extracción estacional, sus hashes, contrastes por régimen y día, los perfiles de los episodios, fichas de los cuatro receptores y el cotejo de la ficha DGA. Los comandos `analizar.py profiles`, `analizar.py surface` e `informe.py`, ubicados en `work/transferencia_fisica_20261113`, realizan el posproceso. `extraer.py` lee los WRF originales y reutiliza sus extracciones verificadas si ya existen. Los datos originales permanecen intactos.
