"""Audita unidades archivadas; calcula un diagnóstico condicional, sin correr modelos."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
import sys
import numpy as np
import pandas as pd
sys.path.insert(0, 'C:/Users/dcitu/Documents/Codex/2026-10-19/es/work/python_deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/Cierre_unidades_2026-11-15'
C = ROOT / 'outputs/Evaluacion_H1_H2_2026-11-12/Controles_dirigidos'
SRC = ROOT / 'work/linux_aermod/epa_source/aermod_source_v26135'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
OUT.mkdir(parents=True, exist_ok=True)

def save(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf8')

archive = ROOT/'work/linux_aermod/aermod_source_26135.zip'
assert sha(archive) == '5092c1d68b77d9407c9f67d497b440a79d2ee746f9ed6515a63ad4a5b11cd8ed'
source_hashes = {}
with zipfile.ZipFile(archive) as z:
    for path in sorted(SRC.glob('*.f')):
        original = z.read('aermod_source_v26135/'+path.name)
        assert path.read_bytes() == original, path
        source_hashes[path.name] = sha(path)
assert len(source_hashes) == 29

segments = [('coset.f',2124,2160,'Factor de masa y etiqueta CONC'),
            ('calc1.f',75,101,'LINE se deriva a ACALC'),
            ('calc1.f',3973,4008,'Integración de fuente de área'),
            ('pitarea.f',213,225,'HRVAL contiene EMIFAC'),
            ('calc1.f',4370,4393,'Agregación con SUMVAL'),
            ('calc2.f',2143,2172,'SUMVAL acumula HRVAL sin conversión volumétrica'),
            ('calc1.f',11390,11421,'Corrección de volumen específica de PVMRM')]
excerpts=[]
for name,a,b,meaning in segments:
    lines=(SRC/name).read_text().splitlines()
    excerpts += [f'## {name}:{a}-{b} - {meaning}',
                 '\n'.join(f'{i}: {lines[i-1]}' for i in range(a,b+1)), '']
(OUT/'Evidencia_codigo.txt').write_text('\n'.join(excerpts),encoding='utf8')

plan=json.loads((C/'Plan.json').read_text())
assert sha(Path(plan['binary'])) == plan['binary_sha256']
rows=[]
for job in plan['jobs']:
    receipt=json.loads((C/'Recibos'/(job['id']+'.json')).read_text())
    assert receipt['status']=='VERIFIED' and receipt['binary_sha256']==plan['binary_sha256']
    folder=C/job['folder']
    for name,digest in job['inputs'].items():
        assert sha(folder/name)==digest
    control=(folder/'aermod.inp').read_text()
    source=(folder/'fuentes_aermod.inc').read_text()
    assert re.search(r'^CO MODELOPT DFAULT CONC\s*$',control,re.M)
    assert not re.search(r'\b(EMISUNIT|CONCUNIT|BACKGRND|BACKUNIT|PVMRM|GRSM|OLM|ARM2)\b',control+source)
    types=[s.split()[3] for s in source.splitlines() if s.startswith('SO LOCATION ')]
    assert types and set(types)=={'LINE'}
    native=next(C/p for p in receipt['outputs'] if p.endswith('receptor_horas.out'))
    assert sha(native)==receipt['outputs'][str(native.relative_to(C))]
    text=native.read_text()
    assert text.startswith('* AERMOD (26135')
    values=[s.split() for s in text.splitlines() if s.strip() and not s.lstrip().startswith('*')]
    assert len(values)==96
    for r in receipt['means']:
        v=[float(f[2]) for f in values if float(f[0])==r['x'] and float(f[1])==r['y']]
        assert len(v)==24 and abs(sum(v)/24-r['mean'])<1e-10
    rows.append(dict(caso=job['id'],fraccion=job['pollutant'],tipo_fuente='LINE',fuentes=len(types),
                     factor_masa_por_defecto=1000000,conversion_volumetrica_explicita=False,
                     valores_horarios=96,media_recibo_reproducida=True,
                     inp_sha256=sha(folder/'aermod.inp'),salida_sha256=sha(native)))
pd.DataFrame(rows).to_csv(OUT/'Auditoria_42_controles.csv',index=False)

surface=ROOT/'outputs/Transferencia_fisica_2026-11-13/Superficie_estacional_seis_puntos.csv'
x=pd.read_csv(surface,parse_dates=['time_UTC'])
assert not x.duplicated(['season','point','time_UTC']).any()
names=['Los Bronces','Piedra Carvajal','Sulfatos','La Paloma']
assert set(names).issubset(x.point.unique())
x=x[x.point.isin(names)].copy()
# Preserve the exact interval convention of the existing physical-transfer audit.
# The initial endpoint belongs to the previous civil day and was extraction support.
civil_start=(x.time_UTC-pd.Timedelta(hours=1)).dt.tz_localize('UTC').dt.tz_convert('America/Santiago').dt.strftime('%Y-%m-%d')
x=x[civil_start.ge(x.season.map({'VERANO':'2016-12-21','INVIERNO':'2017-06-21'}))].copy()
assert np.isfinite(x[['PSFC_Pa','T2_C']]).all().all()
assert x.PSFC_Pa.between(30000,110000).all() and x.T2_C.between(-100,60).all()
x['factor_condicional']=101325/x.PSFC_Pa*(x.T2_C+273.15)/298.15
# Check the derivation independently via V_N/V_amb = (P/P_N)(T_N/T).
inverse_volume=1/((x.PSFC_Pa/101325)*(298.15/(x.T2_C+273.15)))
assert np.allclose(x.factor_condicional,inverse_volume,rtol=1e-14)
summaries=[]
for (season,point),g in x.groupby(['season','point']):
    summaries.append(dict(temporada=season,receptor=point,n_instantes=len(g),
       presion_mediana_hPa=g.PSFC_Pa.median()/100,temperatura_mediana_C=g.T2_C.median(),
       factor_min=g.factor_condicional.min(),factor_p05=g.factor_condicional.quantile(.05),
       factor_mediana=g.factor_condicional.median(),factor_p95=g.factor_condicional.quantile(.95),
       factor_max=g.factor_condicional.max()))
s=pd.DataFrame(summaries)
assert set(s.n_instantes)=={2153,2206} and len(s)==8
s.to_csv(OUT/'Factores_condicionales_resumen.csv',index=False)
x[['season','point','time_UTC','PSFC_Pa','T2_C','factor_condicional']].to_csv(OUT/'Factores_condicionales_horarios.csv',index=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,ax=plt.subplots(figsize=(9.1,4.0),layout='constrained')
for season,offset,color,label in [('VERANO',-.12,'#cd682f','Verano'),('INVIERNO',.12,'#24617b','Invierno')]:
    g=s[s.temporada.eq(season)].set_index('receptor').loc[names]
    y=np.arange(4)+offset
    ax.errorbar(g.factor_mediana,y,xerr=np.array([g.factor_mediana-g.factor_p05,g.factor_p95-g.factor_mediana]),
                fmt='o',capsize=4,lw=2,color=color,label=label)
ax.axvline(1,color='#777777',ls=':',lw=1)
ax.set_yticks(range(4),names);ax.invert_yaxis()
ax.set_xlim(.98,max(s.factor_p95)+.06)
ax.set_xlabel('Factor condicional de referencia volumétrica (adimensional)')
ax.set_title('Diagnóstico con presión superficial y temperatura a 2 m de WRF',loc='left',fontsize=12)
ax.grid(axis='x',alpha=.2);ax.spines[['top','right']].set_visible(False)
ax.legend(loc='upper left',frameon=True,ncol=2,facecolor='white',edgecolor='#dddddd')
fig.savefig(OUT/'Factores_condicionales.png',dpi=190)
fig.savefig(OUT/'Factores_condicionales.svg')
plt.close(fig)
save('Verificacion_analisis.json',dict(status='VERIFIED',date='2026-11-15',
    source_archive_sha256=sha(archive),source_files_unmodified=source_hashes,
    binary_sha256=plan['binary_sha256'],audited_cases=len(rows),hourly_values=96*len(rows),
    scope='42 controles dirigidos; no auditoria nueva de los 3314 casos historicos',
    receipt_means_reproduced=True,wrf_rows=len(x),wrf_input_sha256=sha(surface),
    factors_are_conditional_not_applied_to_concentrations=True,
    no_models_run=True,no_legal_exceedances_calculated=True,
    output_hashes={name:sha(OUT/name) for name in ['Evidencia_codigo.txt',
      'Auditoria_42_controles.csv','Factores_condicionales_resumen.csv',
      'Factores_condicionales_horarios.csv','Factores_condicionales.png','Factores_condicionales.svg']}))
print(s.to_string(index=False))
print('42 controles, 4032 valores y 29 fuentes Fortran comprobados; sin nuevas corridas.')
