"""Produce el informe breve de auditoría; no altera resultados de concentración."""
from pathlib import Path
import json
import hashlib
import sys
import pandas as pd
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/Cierre_unidades_2026-11-15'
PY='C:/Users/dcitu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
font=Path('C:/Users/dcitu/Documents/Codex/2026-10-19/es/work/python_deps/matplotlib/mpl-data/fonts/ttf')
pdfmetrics.registerFont(TTFont('DejaVu',str(font/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DejaVu-Bold',str(font/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVu-Bold',italic='DejaVu',boldItalic='DejaVu-Bold')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyES',fontName='DejaVu',fontSize=9.5,leading=14,spaceAfter=8,textColor=colors.HexColor('#263440')))
styles.add(ParagraphStyle(name='TitleES',fontName='DejaVu-Bold',fontSize=21,leading=26,spaceAfter=15,textColor=colors.HexColor('#17465a')))
styles.add(ParagraphStyle(name='HeadES',fontName='DejaVu-Bold',fontSize=12,leading=16,spaceBefore=10,spaceAfter=7,textColor=colors.HexColor('#17465a')))
styles.add(ParagraphStyle(name='SmallES',parent=styles['BodyES'],fontSize=8,leading=11))
body=[]
def p(t,style='BodyES'): body.append(Paragraph(t,styles[style]))
def h(t):p(t,'HeadES')
def table(rows,widths):
    a=Table([[Paragraph(str(c),styles['SmallES']) for c in row] for row in rows],colWidths=widths,hAlign='LEFT',repeatRows=1)
    a.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7eff2')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#578091')),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#d9e1e5'))]))
    body.append(a)

v=json.loads((OUT/'Verificacion_analisis.json').read_text())
assert v['status']=='VERIFIED' and v['audited_cases']==42 and v['hourly_values']==4032
s=pd.read_csv(OUT/'Factores_condicionales_resumen.csv')
fmt=lambda v,n=3:f'{v:.{n}f}'.replace('.',',')

p('Auditoría de unidades<br/>y pendientes de cierre','TitleES')
p('Tesis Los Bronces Integrado · 15 de noviembre de 2026','SmallES')
p('Se verificó la cadena de unidades de los 42 controles dirigidos de H1/H2. Las medias archivadas se reprodujeron desde 4032 valores horarios. No se ejecutaron nuevas simulaciones ni se sustituyeron las concentraciones existentes.')
h('1. Qué se pudo comprobar')
table([['Componente','Resultado comprobado'],
 ['Código de referencia','29 archivos Fortran de AERMOD 26135 idénticos a la copia ZIP archivada. Se registraron sus huellas SHA-256.'],
 ['Configuración de los controles','Fuentes LINE, DFAULT CONC y etiquetas MP10/MP25; sin EMISUNIT ni opciones de química NO₂ en los archivos examinados.'],
 ['Conversión y salida','El valor predeterminado EMIFAC = 10⁶ convierte gramos a microgramos. LINE utiliza ACALC; AREAIN multiplica la integral por la emisión y EMIFAC. SUMVAL acumula los valores.'],
 ['Recepción','Las medias de los 42 recibos coinciden con el promedio de las 24 salidas de cada receptor, dentro de 10⁻¹⁰ µg/m³.']], [105,404])
h('2. Qué significa para la norma')
p('El D.S. 12/2021 define MP10 en µg/m³N a 25 °C y 1 atm. El factor 10⁶ y la etiqueta µg/m³ de AERMOD no acreditan por sí solos esa referencia volumétrica. En los puntos de cálculo y agregación inspeccionados no se identificó una normalización explícita por presión y temperatura del receptor. Esta conclusión corresponde a una auditoría de código y entradas, no a una certificación regulatoria.')
p('Las conversiones documentadas para fondos gaseosos y las operaciones específicas de NO₂/PVMRM no justifican normalizar el MP10 de estas corridas. Se mantiene pendiente un procedimiento trazable aplicable a la configuración empleada y a cada receptor.')
p('Fuentes: guía EPA 26135, sección 3.3.13; código archivado (Evidencia_codigo.txt); D.S. 12/2021, artículo 2. El binario de Windows se identificó por hash y versión; esta revisión no demuestra identidad binaria con una compilación propia del código.','SmallES')
body.append(PageBreak())
p('Diagnóstico volumétrico condicional','TitleES')
p('Si una concentración estuviera expresada por volumen de aire ambiente y se dispusiera de presión y temperatura representativas de ese volumen, la conservación de masa daría:')
p('<b>C<sub>N</sub> = C<sub>amb</sub> × (101325 / P) × (T / 298,15)</b><br/>P en Pa; T en K. Este cálculo requiere confirmar previamente la base de C<sub>amb</sub>.')
body.append(Image(str(OUT/'Factores_condicionales.png'),width=509,height=224))
p('Puntos: mediana del factor. Segmentos: percentiles 5 y 95 de los instantes WRF disponibles; no son intervalos de incertidumbre. La línea en 1 representa ausencia de cambio volumétrico.','SmallES')
rows=[['Receptor','Verano: mediana [P5; P95]','Invierno: mediana [P5; P95]']]
for receptor in ['Los Bronces','Piedra Carvajal','Sulfatos','La Paloma']:
    row=[receptor]
    for season in ['VERANO','INVIERNO']:
        r=s[(s.receptor==receptor)&(s.temporada==season)].iloc[0]
        row.append(f'{fmt(r.factor_mediana)} [{fmt(r.factor_p05)}; {fmt(r.factor_p95)}]')
    rows.append(row)
table(rows,[127,191,191])
p('El cálculo utiliza 2153 instantes de verano y 2206 de invierno por receptor, con presión superficial y temperatura a 2 m del WRF BASE. Conserva la exclusión del extremo inicial, el faltante nativo invernal y el cierre estival parcial. Son estados simulados en alturas distintas, no una validación de la presión y temperatura del volumen receptor de AERMOD.')
p('<b>No se aplicaron estos factores a las concentraciones.</b> Tampoco se utilizaron para contar superaciones. Una transformación diaria requeriría corregir cada hora comparable antes de promediar; multiplicar dos medias pierde la covariación entre concentración y factor. Las perturbaciones térmicas exigen además definir el estado de referencia de cada escenario.')
body.append(PageBreak())
p('Qué falta para cerrar la interpretación','TitleES')
p('La evidencia numérica de H1/H2 permanece conservada. La auditoría de unidades no modifica sus diferencias en la escala original ni resuelve la transferencia física de las perturbaciones.')
table([['Pendiente','Evidencia o decisión requerida'],
 ['Transferencia en los cuatro receptores','Datos independientes representativos de ubicación y altura, o un alcance explícito de sensibilidad prescrita. La semejanza interna de WRF no identifica sus errores fuera de la estación.'],
 ['Piedra Carvajal','Confirmación DGA del reloj, período de integración y altura de cada sensor en 2016-2017. Los archivos ya aportados no contienen esos antecedentes.'],
 ['Relieve','Identificación del producto original, reproyección/remuestreo, unidad y datum vertical. La auditoría previa comprobó lectura geométrica; no exactitud ni procedencia.'],
 ['MP10 y normativa','Criterio documentado de referencia volumétrica, temperatura y presión pertinentes por receptor/hora, fondo y fuentes completas, y soporte temporal normativo.'],
 ['Caso del titular','Entradas originales completas, inventario, actividad, cotas, receptores y período armonizados. El inventario vial reconstruido no equivale al proyecto integral.']], [112,397])
h('Continuación definida')
p('1. Conservar el cierre actual como análisis de sensibilidad, con H1/H2 respaldadas numéricamente bajo las condiciones ensayadas.<br/>2. Incorporar la trazabilidad de unidades en la discusión sin cambiar los valores de concentración.<br/>3. Completar los antecedentes instrumentales, topográficos y del titular cuando estén disponibles.<br/>4. Acordar el alcance de admisión física antes de diseñar otra campaña. Si se estudian varias columnas, el resultado medirá dependencia de la representación; no sustituirá observaciones independientes.')
h('Reproducción y fuentes')
p('analizar.py verifica archivos, recibos y factores condicionales; informe.py genera este documento. Ambos están en work/cierre_unidades_20261115. Los CSV, huellas y extractos se conservan en outputs/Cierre_unidades_2026-11-15. No se requiere conectar D: para repetir este diagnóstico.','SmallES')
p('<link href="https://gaftp.epa.gov/Air/aqmg/SCRAM/models/preferred/aermod/aermod_userguide.pdf" color="#23647b">EPA: guía AERMOD 26135</link> · <link href="https://www.epa.gov/scram/air-quality-dispersion-modeling-preferred-and-recommended-models" color="#23647b">EPA: código y documentos</link> · <link href="https://www.bcn.cl/leychile/navegar?idNorma=1176988" color="#23647b">BCN: D.S. 12/2021</link>. Consultados el 15-11-2026.','SmallES')

def footer(canvas,doc):
    canvas.saveState();canvas.setFont('DejaVu',8);canvas.setFillColor(colors.HexColor('#627582'))
    canvas.drawString(43,24,'Auditoría de cierre · Sensibilidad prescrita · 15-11-2026')
    canvas.drawRightString(A4[0]-43,24,str(doc.page));canvas.restoreState()
pdf=OUT/'Informe_auditoria_unidades_y_pendientes.pdf'
SimpleDocTemplate(str(pdf),pagesize=A4,leftMargin=43,rightMargin=43,topMargin=39,bottomMargin=40,title='Auditoría de unidades y pendientes de cierre',author='Tesis Los Bronces Integrado').build(body,onFirstPage=footer,onLaterPages=footer)
(OUT/'Reproduccion.md').write_text(f'''# Auditoría del 15 de noviembre de 2026

Esta entrega distingue la conversión de masa verificada de una normalización volumétrica no acreditada. El gráfico es un diagnóstico condicional de presión y temperatura WRF, no una corrección de concentraciones ni una evaluación legal. El alcance nuevo es 42 controles dirigidos y 4032 valores horarios; no una reauditación completa de la campaña histórica.

## Reproducción

Desde la raíz del proyecto, con Python y las dependencias pandas, numpy, matplotlib y reportlab disponibles:

```powershell
& '{PY}' work/cierre_unidades_20261115/analizar.py
& '{PY}' work/cierre_unidades_20261115/informe.py
```

El script usa la instalación ya disponible de matplotlib en el área de trabajo. La reproducción no lanza AERMOD ni modifica entradas, recibos o resultados originales. Para otra instalación, se requiere adaptar esa ruta de biblioteca. Las rutas de entradas están explicitadas en analizar.py. Los 29 archivos Fortran se cotejan byte a byte con el ZIP archivado y los 42 archivos de configuración y salidas con sus recibos.

## Criterio del diagnóstico condicional

Se calcula f = (101325/P) (T/298.15) con P superficial WRF en Pa y T2 en kelvin. La fórmula deriva de V_N/V_amb = (P/P_N)(T_N/T). Los percentiles describen los instantes simulados disponibles; no probabilidades calibradas de error. Se excluye el instante inicial de apoyo con la misma convención civil que la auditoría de transferencia. No se rellenan faltantes.

No se ha autorizado científicamente la aplicación de ese factor a la concentración. Faltan la referencia volumétrica inequívoca del resultado y la representatividad de P/T para el volumen y escenario. El promedio correcto, si se justificara, sería media(C_h f_h), no media(C_h) media(f_h).

## Fuentes oficiales

- [Guía EPA 26135, sección 3.3.13](https://gaftp.epa.gov/Air/aqmg/SCRAM/models/preferred/aermod/aermod_userguide.pdf).
- [Código y documentos AERMOD](https://www.epa.gov/scram/air-quality-dispersion-modeling-preferred-and-recommended-models).
- [D.S. 12/2021, artículo 2](https://www.bcn.cl/leychile/navegar?idNorma=1176988).
- El [TSD GRSM](https://nepis.epa.gov/Exe/ZyPURL.cgi?Dockey=P101CGV8.TXT), sección 5, describe NOx/NO2 a referencia estándar. Esa afirmación específica no se extrapoló a MP10 LINE CONC.

## Límites que no cambian

Transferencia física, metadatos instrumentales, procedencia vertical del relieve, equivalencia integral del titular y contraste normativo completo siguen condicionados a evidencia adicional. No se reactivaron colas ni se enviaron solicitudes externas.
''',encoding='utf8')
print(pdf)
