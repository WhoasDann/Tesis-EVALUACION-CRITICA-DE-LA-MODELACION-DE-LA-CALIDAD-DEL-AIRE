"""Comprueba contenido, referencias y conservación antes de publicar."""
from pathlib import Path
import hashlib,json,re
from collections import Counter
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).parent
OUT=ROOT/'outputs/Cierre_unidades_2026-11-15';STAGE=WORK/'manuscrito'
SOURCE=Path('C:/Users/dcitu/OneDrive/Escritorio/TESIS escrito/Tesis_DC/Template-Tesis-diqbtm')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((OUT/'Originales_sha256.json').read_text(encoding='utf8'))
for name,digest in original.items():assert sha(SOURCE/name)==digest,('original changed',name)
changed=[name for name,digest in original.items() if name!='main.pdf' and sha(STAGE/name)!=digest]
assert changed==['7_1_Discusión.tex'],changed
tex='\n'.join(re.sub(r'(?<!\\)%[^\n]*','',p.read_text(encoding='utf8')) for p in STAGE.glob('*.tex') if p.name not in ['template.tex','template_config.tex','example.tex'])
labels=re.findall(r'\\label\{([^}]+)\}',tex)
assert not [k for k,v in Counter(labels).items() if v>1]
refs=re.findall(r'\\(?:eqref|ref|pageref|autoref)\{([^}]+)\}',tex)
assert not set(refs)-set(labels)
cites={k for m in re.findall(r'\\cite\w*\*?(?:\[[^\]]*\]){0,2}\{([^}]+)\}',tex) for k in m.split(',')}
bib=set(re.findall(r'@\w+\s*\{\s*([^,]+),',(STAGE/'library.bib').read_text(encoding='utf8')))
assert not cites-bib
log=(STAGE/'main.log').read_text(encoding='utf8',errors='replace')
assert not re.search(r'Overfull|Underfull|undefined references|Citation .* undefined|Label\(s\) may have changed|LaTeX Error|^!',log,re.M)
warnings=[line for line in log.splitlines() if 'Warning' in line]
assert all('Font Warning' in line for line in warnings),warnings
pdf=PdfReader(STAGE/'main.pdf');pages=[p.extract_text() or '' for p in pdf.pages]
hits=[i+1 for i,t in enumerate(pages) if 'Los42controlesdirigidosemplearon' in re.sub(r'\s+','',t)]
assert len(hits)==1,hits
assert 'microgramos' in pages[hits[0]-1]
old=PdfReader(SOURCE/'main.pdf');oldpages=[p.extract_text() or '' for p in old.pages]
diff=[i+1 for i in range(max(len(pages),len(oldpages))) if (pages[i] if i<len(pages) else '') != (oldpages[i] if i<len(oldpages) else '')]
assert len(pages)==len(oldpages), 'Revisar la paginación antes de publicar.'
# The template numbers manuscript lines. Later pages can differ only in those
# counters; all their source files are checked unchanged above.
review=sorted({k for i in hits for k in [i-1,i,i+1] if 1<=k<=len(pages)}|{i for i in diff if i<=12})
result=dict(status='STATIC_AND_NUMERIC_VERIFIED_VISUAL_PENDING',pages=len(pages),previous_pages=len(oldpages),labels=len(labels),citations=len(cites),
  originals_unchanged=True,changed=changed,pdf_sha256=sha(STAGE/'main.pdf'),new_models_run=0,
  remaining_warnings=warnings,changed_text_pages=diff,pages_for_visual_review=review,
  report_pdf_sha256=sha(OUT/'Informe_auditoria_unidades_y_pendientes.pdf'))
(OUT/'Verificacion_manuscrito.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
