# Auditoría del 15 de noviembre de 2026

Esta entrega distingue la conversión de masa verificada de una normalización volumétrica no acreditada. El gráfico es un diagnóstico condicional de presión y temperatura WRF, no una corrección de concentraciones ni una evaluación legal. El alcance nuevo es 42 controles dirigidos y 4032 valores horarios; no una reauditación completa de la campaña histórica.

## Reproducción

Desde la raíz del proyecto, con Python y las dependencias pandas, numpy, matplotlib y reportlab disponibles:

```powershell
& 'C:/Users/dcitu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' work/cierre_unidades_20261115/analizar.py
& 'C:/Users/dcitu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' work/cierre_unidades_20261115/informe.py
```

El script usa la instalación ya disponible de matplotlib en el área de trabajo. La reproducción no lanza AERMOD ni modifica entradas, recibos o resultados originales. Para otra instalación, se requiere adaptar esa ruta de biblioteca. Las rutas de entradas están explicitadas en analizar.py. Los 29 archivos Fortran se cotejan byte a byte con el ZIP archivado y los 42 archivos de configuración y salidas con sus recibos.

## Criterio del diagnóstico condicional

Se calcula f = (101325/P) (T/298.15) con P superficial WRF en Pa y T2 en kelvin. La fórmula deriva de V_N/V_amb = (P/P_N)(T_N/T). Los percentiles describen los instantes simulados disponibles; no probabilidades calibradas de error. Se excluye el instante inicial de apoyo con la misma convención civil que la auditoría de transferencia. No se rellenan faltantes.

No se ha autorizado científicamente la aplicación de ese factor a la concentración. Faltan la referencia volumétrica inequívoca del resultado y la representatividad de P/T para el volumen y escenario. El promedio correcto, si se justificara, sería media(C_h f_h), no media(C_h) media(f_h).

## Fuentes oficiales

- [Guía EPA 26135, sección 3.3.13](https://gaftp.epa.gov/Air/aqmg/SCRAM/models/preferred/aermod/aermod_userguide.pdf).
- [Código y documentos AERMOD](https://www.epa.gov/scram/air-quality-dispersion-modeling-preferred-and-recommended-models).
- [D.S. 12/2021, artículo 2](https://www.bcn.cl/leychile/navegar?idNorma=1176988).
- El [TSD GRSM](https://nepis.epa.gov/Exe/ZyPURL.cgi?Dockey=P101CGV8.TXT), sección 5, describe NOx/NO2 a referencia estándar. Esa afirmación específica no se extrapoló a MP10 LINE CONC.

## Límites que no cambian

Transferencia física, metadatos instrumentales, procedencia vertical del relieve, equivalencia integral del titular y contraste normativo completo siguen condicionados a evidencia adicional. No se reactivaron colas ni se enviaron solicitudes externas.
